import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
import os
import matplotlib.ticker as mticker
import matplotlib.colors as colors
plt.rc('font', family='Times New Roman')
config = {
"font.size": 30,
"mathtext.fontset":'stix',
"font.serif": ['SimSun'],
}
rcParams.update(config) # Latex 字体设置
#------------------------------------------------------------
def plotchi(numk):
    dataname = "chi-val-kn-" + str(format(numk,"0>3d")) + ".dat"
    dataname = "Bx_kbt-phase.dat"
    picname = os.path.splitext(dataname)[0] + ".png"
    da = np.loadtxt(dataname) 
    # 提取数据
    x0 = np.array(da[0, :])  # x 坐标
    y0 = np.array(da[1, :])  # y 坐标
    z0 = np.array(da[2, :])  # z 值（密度值）
    xn = int(np.sqrt(len(x0)))
    x0 = x0.reshape(xn, xn)
    y0 = y0.reshape(xn, xn)
    z0 = z0.reshape(xn,xn)
    plt.figure(figsize = (10,10))
    # 确定 x 和 y 的范围
    x_min, x_max = np.min(x0), np.max(x0)
    y_min, y_max = np.min(y0), np.max(y0)
    # 绘制密度图
    plt.figure(figsize=(10, 10))
    sc = plt.imshow(z0, extent=[x_min, x_max, y_min, y_max],  interpolation = 'spline16', cmap = "jet",  origin = 'lower')  
    # 标记密度为 0 的边界
    # zero_contour = plt.contour(x0, y0, z0, levels = [0.00078431], colors='black', linewidths=2)  
    # plt.clabel(zero_contour, inline=True, fontsize=10, fmt='0')
    cb = plt.colorbar(sc,fraction = 0.045,extend='both')  # 调整colorbar的大小和图之间的间距
    # cb.ax.tick_params(labelsize = 20)
    cb.ax.tick_params(size = 0.8)
    cb.ax.set_title(r"$\Delta_0$", fontsize = 30)
    font2 = {'family': 'Times New Roman','weight': 'normal','size': 40}
    # # cb.set_label('ldos',fontdict=font2) #设置colorbar的标签字体及其大小
    # # plt.scatter(x0, y0, s = 5, color='blue',edgecolor="blue")
    plt.axis('scaled')
    plt.ylabel(r"$k_BT$",font2)
    plt.xlabel(r"$B_c$",font2)
    # tit = "$J_x= " + str(cont) + "$"
    # plt.title(tit,font2)
    # plt.yticks([],fontproperties='Times New Roman', size = 40)
    # plt.xticks([],fontproperties='Times New Roman', size = 40)
    plt.tick_params(axis='x',width = 0.,length = 10)
    plt.tick_params(axis='y',width = 0,length = 10)
    ax = plt.gca()
    ax.locator_params(axis='x', nbins = 5)  # x 轴最多显示 3 个刻度
    ax.locator_params(axis='y', nbins = 5)  # y 轴最多显示 3 个刻度
    ax.spines["bottom"].set_linewidth(1.5)
    ax.spines["left"].set_linewidth(1.5) 
    ax.spines["right"].set_linewidth(1.5)
    ax.spines["top"].set_linewidth(1.5)
    # plt.show()
    plt.savefig(picname, dpi = 300,bbox_inches = 'tight')
    plt.close()
#------------------------------------------------------------
if __name__=="__main__":
    # plotband()
    kn = 128
    plotchi(kn)
    






