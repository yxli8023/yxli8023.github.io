import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
import os
import matplotlib.gridspec as gridspec
from matplotlib.path import Path
import matplotlib.colors as mcolors
from matplotlib.colors import LinearSegmentedColormap


plt.rc('font', family='Times New Roman')
config = {
"font.size": 35,
"mathtext.fontset":'stix',
"font.serif": ['SimSun'],
}
rcParams.update(config) # Latex 字体设置
#-----------------------------------------------------------------------------------------------
def plot_Chern_Number_2D_couple():
    dataname1 = "Phase-V0-delta0-HP.dat"
    dataname2 = "Phase-V0-delta0-HM.dat"
    picname = "Chern-couple.png"
    da = np.loadtxt(dataname1) 
    da2 = np.loadtxt(dataname2) 
    x0 = da[:, 0]  # delta0 数据
    y0 = da[:, 1]  # d0 数据
    z0 = np.array(da[:, 2])  # Chern 数数据
    z1 = np.array(da2[:, 2])  # Chern 数数据

    # 获取 delta0 和 d0 的范围
    delta0_min, delta0_max = np.min(x0), np.max(x0)
    d0_min, d0_max = np.min(y0), np.max(y0)

    # 将 z0 数据重塑为二维数组
    xn = int(np.sqrt(len(x0)))
    z0 = z0.reshape(xn, xn) + z1.reshape(xn, xn)

    # 创建绘图
    plt.figure(figsize=(10, 10))
    with open("LightTemperatureMap.dat", "r") as file:
        lines = file.readlines()
    # 解析颜色数据
    colors = []
    for line in lines:
        # 去掉多余的字符（例如 "RGBColor[" 和 "]"）
        line = line.replace("RGBColor[", "").replace("]", "").strip()
        # 按逗号分割，提取 R, G, B 值
        r, g, b = map(float, line.split(","))
        colors.append((r, g, b))

    # 将颜色数据转换为 matplotlib 的 colormap 格式
    cmap = LinearSegmentedColormap.from_list("LightTemperatureMap", colors)
    # sc = plt.imshow(z0, interpolation = 'bilinear', cmap="RdYlBu", origin='lower', extent=[d0_min, d0_max, delta0_min, delta0_max])
    # sc = plt.imshow(z0, cmap="RdYlBu", origin='lower', extent=[d0_min, d0_max, delta0_min, delta0_max])
    sc = plt.imshow(z0, interpolation = 'bilinear',cmap = cmap, origin='lower', extent=[d0_min, d0_max, delta0_min, delta0_max])

    # 添加 colorbar
    cb = plt.colorbar(sc, fraction = 0.04, ticks = [np.min(z0), np.max(z0)], extend='both')
    cb.ax.set_title(r"$C$", fontsize=30)
    cb.ax.tick_params(size=1)
    cb.ax.set_yticklabels([format(np.min(z0), ".1f"), format(np.max(z0), ".1f")])

    # 设置坐标轴标签
    font2 = {'family': 'Times New Roman', 'weight': 'normal', 'size': 40}
    plt.xlabel(r"$\Delta_0$", font2)
    plt.ylabel(r"$V_0$", font2)
    plt.title(r"$H^++H^-$")

    # 设置坐标轴刻度
    plt.yticks(np.linspace(delta0_min, delta0_max, 5), fontproperties = 'Times New Roman', size=30)  # 显示 5 个刻度
    plt.xticks(np.linspace(d0_min, d0_max, 5), fontproperties = 'Times New Roman', size=30)  # 显示 5 个刻度
    plt.tick_params(axis = 'x', width=1, length=8, direction = "in")
    plt.tick_params(axis = 'y', width=1, length=8, direction = "in")

    # 设置横纵方向比例一致
    ax = plt.gca()
    ax.set_aspect('auto')  # 自动调整比例
    # 或者手动设置比例
    # ax.set_aspect((delta0_max - delta0_min) / (d0_max - d0_min))  # 根据数据范围设置比例

    # 设置坐标轴样式
    ax.spines["bottom"].set_linewidth(1.5)
    ax.spines["left"].set_linewidth(1.5)
    ax.spines["right"].set_linewidth(1.5)
    ax.spines["top"].set_linewidth(1.5)

    # 保存图像
    plt.savefig(picname, dpi=300, bbox_inches = 'tight')
    plt.close()

#------------------------------------------------------------
if __name__=="__main__":
    plot_Chern_Number_2D_couple()
        









