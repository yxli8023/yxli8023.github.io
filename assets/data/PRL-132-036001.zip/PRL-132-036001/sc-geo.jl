# =========================================================
# fig5b_mpi_compute_dat.jl
#
# Fig. 5(b): linearized gap-equation eigenvalues
# Dispersive Lieb lattice + RPA pairing interaction
#
# MPI parallelization:
#   Different MPI ranks calculate different mu_c points.
#
# Output:
#   PRL132_036001/fig5b_reproduction/fig5b_gap_eigenvalues.dat
# =========================================================

using MPI,LinearAlgebra,FFTW,Arpack,LinearMaps,Printf,Random

# =========================================================
# 0) MPI initialization
# =========================================================
MPI.Init()

comm = MPI.COMM_WORLD
rank = MPI.Comm_rank(comm)
nprocs = MPI.Comm_size(comm)

# Avoid too many FFTW threads inside each MPI rank
FFTW.set_num_threads(1)

if rank == 0
    println("MPI size = $nprocs")
end


# =========================================================
# 1) Basic utilities
# =========================================================
pair_index(a, b, norb) = (a - 1) * norb + b

function float_to_tag(x; ndigits=3)
    s = @sprintf("%.*f", ndigits, x)
    s = replace(s, "." => "p")
    s = replace(s, "-" => "m")
    return s
end

function ensure_dir(path::String)
    if !isdir(path)
        mkpath(path)
    end
end


# =========================================================
# 2) Periodic-basis dispersive Lieb lattice Hamiltonian
# =========================================================
function lieb_hamiltonian_periodic(kx, ky; t=1.0, t2=0.4, t3=0.15, t3p=0.2)
    epsA = -2.0 * t3 * (cos(kx) + cos(ky))
    epsB = -2.0 * t3 * cos(kx) - 2.0 * t3p * cos(ky)
    epsC = -2.0 * t3 * cos(ky) - 2.0 * t3p * cos(kx)

    epsx  = -2.0 * t  * cos(kx / 2.0)
    epsy  = -2.0 * t  * cos(ky / 2.0)
    epsxy = -4.0 * t2 * cos(kx / 2.0) * cos(ky / 2.0)

    phaseB = exp(im * kx / 2.0)
    phaseC = exp(im * ky / 2.0)

    H = zeros(ComplexF64, 3, 3)

    H[1, 1] = epsA
    H[2, 2] = epsB
    H[3, 3] = epsC

    H[1, 2] = epsx * conj(phaseB)
    H[2, 1] = epsx * phaseB

    H[1, 3] = epsy * conj(phaseC)
    H[3, 1] = epsy * phaseC

    H[2, 3] = epsxy * phaseB * conj(phaseC)
    H[3, 2] = epsxy * conj(phaseB) * phaseC

    return H
end


function precompute_eigensystem_periodic(Nk::Int)
    if isodd(Nk)
        error("Nk should be even.")
    end

    dk = 2.0 * pi / Nk

    evals = zeros(Float64, Nk, Nk, 3)
    evecs = zeros(ComplexF64, Nk, Nk, 3, 3)

    if rank == 0
        println("Diagonalizing periodic-basis Hamiltonian ...")
    end

    for iy in 1:Nk
        ky = (iy - 1) * dk
        for ix in 1:Nk
            kx = (ix - 1) * dk
            H = lieb_hamiltonian_periodic(kx, ky)
            E = eigen(H)
            evals[iy, ix, :] .= real(E.values)
            evecs[iy, ix, :, :] .= E.vectors
        end
    end

    if rank == 0
        println("Diagonalization finished.")
    end

    return Dict(
        "Nk" => Nk,
        "dk" => dk,
        "evals" => evals,
        "evecs" => evecs,
    )
end


# =========================================================
# 3) Fermi functions
# =========================================================
function fermi_scalar(x::Float64, T::Float64)
    y = clamp(x / T, -700.0, 700.0)
    return 1.0 / (exp(y) + 1.0)
end

function minus_fermi_derivative_scalar(x::Float64, T::Float64)
    y = clamp(x / (2.0 * T), -350.0, 350.0)
    return 1.0 / (4.0 * T * cosh(y)^2)
end

function fill_fermi!(fout, evals, mu::Float64, T::Float64)
    @inbounds for I in eachindex(evals)
        fout[I] = fermi_scalar(evals[I] - mu, T)
    end
end

function lindhard_factor_array(Eq, Ek, fq, fk, mu::Float64, T::Float64; eps=1e-10)
    Nk = size(Ek, 1)
    F = zeros(Float64, Nk, Nk, 3, 3)

    @inbounds for iy in 1:Nk, ix in 1:Nk
        for n in 1:3
            for m in 1:3
                denom = Eq[iy, ix, n] - Ek[iy, ix, m]
                numer = fk[iy, ix, m] - fq[iy, ix, n]

                if abs(denom) > eps
                    F[iy, ix, n, m] = numer / denom
                else
                    emid = 0.5 * (Eq[iy, ix, n] + Ek[iy, ix, m]) - mu
                    F[iy, ix, n, m] = minus_fermi_derivative_scalar(emid, T)
                end
            end
        end
    end

    return F
end

function pair_factor_array(xi_k, xi_mk, T::Float64; eps=1e-10)
    Nk = size(xi_k, 1)
    P = zeros(Float64, Nk, Nk, 3, 3)

    @inbounds for iy in 1:Nk, ix in 1:Nk
        for n in 1:3
            x = xi_k[iy, ix, n]
            fx = fermi_scalar(x, T)

            for m in 1:3
                y = xi_mk[iy, ix, m]
                fy = fermi_scalar(y, T)

                denom = x + y
                numer = 1.0 - fx - fy

                if abs(denom) > eps
                    P[iy, ix, n, m] = numer / denom
                else
                    xeff = 0.5 * (x - y)
                    P[iy, ix, n, m] = minus_fermi_derivative_scalar(xeff, T)
                end
            end
        end
    end

    return P
end


# =========================================================
# 4) RPA susceptibility and pairing interaction
# =========================================================
function make_gamma0(U::Float64; norb=3)
    dim = norb * norb
    Gamma0 = zeros(ComplexF64, dim, dim)

    for l in 1:norb
        idx = pair_index(l, l, norb)
        Gamma0[idx, idx] = U
    end

    return Gamma0
end

function compute_chi0_matrix_for_one_q(F, Uq, Uk)
    Nk = size(F, 1)
    norb = size(Uk, 3)
    dim = norb * norb

    chi0 = zeros(ComplexF64, dim, dim)

    @inbounds for iy in 1:Nk, ix in 1:Nk
        for n in 1:norb
            for m in 1:norb
                fval = F[iy, ix, n, m]

                for a in 1:norb
                    uqa = Uq[iy, ix, a, n]
                    for c in 1:norb
                        qfac = uqa * conj(Uq[iy, ix, c, n])

                        for d in 1:norb
                            ukd = Uk[iy, ix, d, m]
                            for b in 1:norb
                                row = pair_index(a, b, norb)
                                col = pair_index(c, d, norb)

                                kfac = ukd * conj(Uk[iy, ix, b, m])
                                chi0[row, col] += fval * qfac * kfac
                            end
                        end
                    end
                end
            end
        end
    end

    chi0 ./= (Nk * Nk)
    return chi0
end

function rpa_chi_s_chi_c_from_chi0bar(chi0bar, Gamma0)
    dim = size(chi0bar, 1)
    I9 = Matrix{ComplexF64}(I, dim, dim)

    chi0_sc = 2.0 .* chi0bar

    As = I9 .- Gamma0 * chi0bar
    Ac = I9 .+ Gamma0 * chi0bar

    chi_s = As \ chi0_sc
    chi_c = Ac \ chi0_sc

    return chi_s, chi_c
end

function effective_pairing_interactions(chi_s, chi_c, Gamma0)
    Vt = Gamma0 * (-0.25 .* chi_s .- 0.25 .* chi_c) * Gamma0
    Vs = Gamma0 * ( 0.75 .* chi_s .- 0.25 .* chi_c) * Gamma0 .+ Gamma0
    return Vs, Vt
end


# =========================================================
# 5) Compute RPA interactions Vs(q), Vt(q)
# =========================================================
function compute_one_q_row_interactions(iy, sy, q_shifts, evals, evecs, fk, mu, T, Gamma0)
    Nk = size(evals, 1)
    norb = size(evecs, 3)
    dim = norb * norb

    yplus = [mod(y - 1 + sy, Nk) + 1 for y in 1:Nk]

    Vs_row = zeros(ComplexF64, Nk, dim, dim)
    Vt_row = zeros(ComplexF64, Nk, dim, dim)

    Eq = zeros(Float64, Nk, Nk, norb)
    Uq = zeros(ComplexF64, Nk, Nk, norb, norb)
    fq = zeros(Float64, Nk, Nk, norb)

    @inbounds for (iqx, sx) in enumerate(q_shifts)
        xplus = [mod(x - 1 + sx, Nk) + 1 for x in 1:Nk]

        for y in 1:Nk
            yp = yplus[y]
            for x in 1:Nk
                xp = xplus[x]
                Eq[y, x, :] .= evals[yp, xp, :]
                Uq[y, x, :, :] .= evecs[yp, xp, :, :]
            end
        end

        fill_fermi!(fq, Eq, mu, T)

        F = lindhard_factor_array(Eq, evals, fq, fk, mu, T)
        chi0bar = compute_chi0_matrix_for_one_q(F, Uq, evecs)

        chi_s, chi_c = rpa_chi_s_chi_c_from_chi0bar(chi0bar, Gamma0)
        Vs, Vt = effective_pairing_interactions(chi_s, chi_c, Gamma0)

        Vs_row[iqx, :, :] .= Vs
        Vt_row[iqx, :, :] .= Vt
    end

    return iy, Vs_row, Vt_row
end

function compute_rpa_interactions_for_mu(eig_data; mu=0.70, T=0.01, U=0.86)
    evals = eig_data["evals"]
    evecs = eig_data["evecs"]
    Nk = eig_data["Nk"]

    norb = size(evecs, 3)
    dim = norb * norb

    Gamma0 = make_gamma0(U; norb=norb)

    fk = similar(evals)
    fill_fermi!(fk, evals, mu, T)

    q_shifts = collect(0:Nk-1)

    Vs_q = zeros(ComplexF64, Nk, Nk, dim, dim)
    Vt_q = zeros(ComplexF64, Nk, Nk, dim, dim)

    println("Rank $rank: computing RPA interactions, mu = $(round(mu, digits=4))")
    flush(stdout)

    for (iqy, sy) in enumerate(q_shifts)
        if iqy == 1 || iqy % 4 == 0 || iqy == Nk
            @printf("Rank %d: q-row %4d / %4d\n", rank, iqy, Nk)
            flush(stdout)
        end

        _, Vs_row, Vt_row = compute_one_q_row_interactions(
            iqy, sy, q_shifts, evals, evecs, fk, mu, T, Gamma0
        )

        Vs_q[iqy, :, :, :] .= Vs_row
        Vt_q[iqy, :, :, :] .= Vt_row
    end

    return Vs_q, Vt_q
end


# =========================================================
# 6) Convert V(q) to gap-equation kernel K(q)
# =========================================================
function convert_V_to_gap_kernel(Vq; norb=3)
    Nk = size(Vq, 1)
    dim = norb * norb

    Kq = zeros(ComplexF64, Nk, Nk, dim, dim)

    @inbounds for a in 1:norb
        for d in 1:norb
            out_pair = pair_index(a, d, norb)

            for b in 1:norb
                for c in 1:norb
                    mid_pair = pair_index(b, c, norb)

                    row = pair_index(a, b, norb)
                    col = pair_index(c, d, norb)

                    Kq[:, :, out_pair, mid_pair] .= Vq[:, :, row, col]
                end
            end
        end
    end

    return Kq
end


# =========================================================
# 7) Pair propagator Pi(k)
# =========================================================
function compute_pair_propagator(eig_data; mu=0.70, T=0.01)
    evals = eig_data["evals"]
    evecs = eig_data["evecs"]

    Nk = eig_data["Nk"]
    norb = size(evecs, 3)
    dim = norb * norb

    neg = [mod(-(i - 1), Nk) + 1 for i in 1:Nk]

    evals_mk = zeros(Float64, Nk, Nk, norb)
    evecs_mk = zeros(ComplexF64, Nk, Nk, norb, norb)

    @inbounds for y in 1:Nk
        yy = neg[y]
        for x in 1:Nk
            xx = neg[x]
            evals_mk[y, x, :] .= evals[yy, xx, :]
            evecs_mk[y, x, :, :] .= evecs[yy, xx, :, :]
        end
    end

    xi_k = evals .- mu
    xi_mk = evals_mk .- mu

    P = pair_factor_array(xi_k, xi_mk, T)

    Pi = zeros(ComplexF64, Nk, Nk, dim, dim)

    @inbounds for y in 1:Nk, x in 1:Nk
        for n in 1:norb
            for m in 1:norb
                pval = P[y, x, n, m]

                for a in 1:norb
                    uan = evecs[y, x, a, n]
                    for c in 1:norb
                        leftfac = uan * conj(evecs[y, x, c, n])

                        for b in 1:norb
                            ubm = evecs_mk[y, x, b, m]
                            for d in 1:norb
                                row = pair_index(a, b, norb)
                                col = pair_index(c, d, norb)

                                rightfac = ubm * conj(evecs_mk[y, x, d, m])
                                Pi[y, x, row, col] += pval * leftfac * rightfac
                            end
                        end
                    end
                end
            end
        end
    end

    return Pi
end


# =========================================================
# 8) Singlet/triplet projection
# =========================================================
function project_gap_channel(v::Vector{ComplexF64}, Nk::Int; norb=3, channel="singlet")
    dim = norb * norb
    Delta = reshape(v, Nk, Nk, dim)
    out = similar(Delta)

    neg = [mod(-(i - 1), Nk) + 1 for i in 1:Nk]
    sign = channel == "singlet" ? 1.0 : -1.0

    @inbounds for y in 1:Nk
        yy = neg[y]
        for x in 1:Nk
            xx = neg[x]

            for a in 1:norb
                for b in 1:norb
                    pab = pair_index(a, b, norb)
                    pba = pair_index(b, a, norb)

                    out[y, x, pab] =
                        0.5 * (Delta[y, x, pab] + sign * Delta[yy, xx, pba])
                end
            end
        end
    end

    return vec(out)
end


# =========================================================
# 9) Linearized gap-equation operator
# =========================================================
function make_gap_linear_operator(Kq, Pik; norb=3, channel="singlet")
    Nk = size(Kq, 1)
    dim = norb * norb
    total_dim = Nk * Nk * dim
    norm_factor = Nk * Nk

    Kfft = fft(Kq, (1, 2))

    function mv(v)
        vc = Vector{ComplexF64}(v)

        vproj = project_gap_channel(vc, Nk; norb=norb, channel=channel)
        Delta = reshape(vproj, Nk, Nk, dim)

        B = zeros(ComplexF64, Nk, Nk, dim)

        @inbounds for y in 1:Nk, x in 1:Nk
            for i in 1:dim
                acc = 0.0 + 0.0im
                for j in 1:dim
                    acc += Pik[y, x, i, j] * Delta[y, x, j]
                end
                B[y, x, i] = acc
            end
        end

        Bfft = fft(B, (1, 2))
        Cfft = zeros(ComplexF64, Nk, Nk, dim)

        @inbounds for y in 1:Nk, x in 1:Nk
            for o in 1:dim
                acc = 0.0 + 0.0im
                for m in 1:dim
                    acc += Kfft[y, x, o, m] * Bfft[y, x, m]
                end
                Cfft[y, x, o] = acc
            end
        end

        C = ifft(Cfft, (1, 2))
        Y = -C ./ norm_factor

        yproj = project_gap_channel(vec(Y), Nk; norb=norb, channel=channel)

        return yproj
    end

    return LinearMap{ComplexF64}(mv, total_dim, total_dim; ismutating=false)
end


function solve_leading_gap_eigenvalue(Kq, Pik; norb=3, channel="singlet",
                                      nev=4, eig_tol=1e-6, eig_maxiter=500,
                                      seed=1234)
    Nk = size(Kq, 1)
    dim = norb * norb
    total_dim = Nk * Nk * dim

    Lop = make_gap_linear_operator(Kq, Pik; norb=norb, channel=channel)

    Random.seed!(seed)
    v0 = randn(ComplexF64, total_dim)
    v0 = project_gap_channel(v0, Nk; norb=norb, channel=channel)

    nrm = norm(v0)
    if nrm < 1e-14
        error("Initial vector vanished after projection.")
    end
    v0 ./= nrm

    vals = nothing

    try
        vals, vecs, nconv, niter, nmult, resid = eigs(
            Lop;
            nev=nev,
            which=:LR,
            tol=eig_tol,
            maxiter=eig_maxiter,
            v0=v0,
        )
    catch err
        @warn "ARPACK failed for channel=$channel. Return NaN." exception=(err, catch_backtrace())
        return NaN
    end

    vals_real = real.(vals)
    return maximum(vals_real)
end


# =========================================================
# 10) One mu point
# =========================================================
function compute_one_mu(eig_data, mu; T=0.01, U=0.86,
                        nev=4, eig_tol=1e-6, eig_maxiter=500)
    norb = size(eig_data["evecs"], 3)

    Vs_q, Vt_q = compute_rpa_interactions_for_mu(
        eig_data;
        mu=mu,
        T=T,
        U=U,
    )

    Ks_q = convert_V_to_gap_kernel(Vs_q; norb=norb)
    Kt_q = convert_V_to_gap_kernel(Vt_q; norb=norb)

    Pi_k = compute_pair_propagator(
        eig_data;
        mu=mu,
        T=T,
    )

    println("Rank $rank: solving singlet eigenvalue, mu = $(round(mu, digits=4))")
    lambda_s = solve_leading_gap_eigenvalue(
        Ks_q,
        Pi_k;
        norb=norb,
        channel="singlet",
        nev=nev,
        eig_tol=eig_tol,
        eig_maxiter=eig_maxiter,
        seed=1000 + round(Int, 10000 * mu),
    )

    println("Rank $rank: solving triplet eigenvalue, mu = $(round(mu, digits=4))")
    lambda_t = solve_leading_gap_eigenvalue(
        Kt_q,
        Pi_k;
        norb=norb,
        channel="triplet",
        nev=nev,
        eig_tol=eig_tol,
        eig_maxiter=eig_maxiter,
        seed=2000 + round(Int, 10000 * mu),
    )

    return lambda_s, lambda_t
end


# =========================================================
# 11) DAT save/load
# =========================================================
function read_partial_dat(filename::String)
    done = Dict{Int, Tuple{Float64, Float64, Float64}}()

    if !isfile(filename)
        return done
    end

    open(filename, "r") do io
        for line in eachline(io)
            s = strip(line)
            if isempty(s) || startswith(s, "#")
                continue
            end

            vals = split(s)
            if length(vals) >= 4
                imu = parse(Int, vals[1])
                mu = parse(Float64, vals[2])
                ls = parse(Float64, vals[3])
                lt = parse(Float64, vals[4])
                done[imu] = (mu, ls, lt)
            end
        end
    end

    return done
end

function write_partial_dat(filename::String, rows::Dict{Int, Tuple{Float64, Float64, Float64}};
                           Nk, T, U, rank)
    ensure_dir(dirname(filename))

    keys_sorted = sort(collect(keys(rows)))

    open(filename, "w") do io
        println(io, "# Partial Fig.5(b) data")
        println(io, "# rank = $rank")
        println(io, "# Nk = $Nk")
        println(io, "# T = $T")
        println(io, "# U = $U")
        println(io, "# columns: index  mu_c  lambda_singlet  lambda_triplet")

        for imu in keys_sorted
            mu, ls, lt = rows[imu]
            @printf(io, "%6d  %.12f  %.12e  %.12e\n", imu, mu, ls, lt)
        end
    end
end

function merge_partial_dat(final_file::String, partial_files::Vector{String};
                           mu_list, Nk, T, U)
    nmu = length(mu_list)

    lambda_s = fill(NaN, nmu)
    lambda_t = fill(NaN, nmu)

    for pf in partial_files
        rows = read_partial_dat(pf)

        for (imu, tup) in rows
            mu, ls, lt = tup
            if 1 <= imu <= nmu
                lambda_s[imu] = ls
                lambda_t[imu] = lt
            end
        end
    end

    ensure_dir(dirname(final_file))

    open(final_file, "w") do io
        println(io, "# Fig.5(b) gap-equation eigenvalues")
        println(io, "# Nk = $Nk")
        println(io, "# T = $T")
        println(io, "# U = $U")
        println(io, "# columns: index  mu_c  lambda_singlet  lambda_triplet")

        for imu in 1:nmu
            @printf(
                io,
                "%6d  %.12f  %.12e  %.12e\n",
                imu,
                mu_list[imu],
                lambda_s[imu],
                lambda_t[imu],
            )
        end
    end

    println("Final data saved to: $final_file")
end


# =========================================================
# 12) Main parameters
# =========================================================

project_dir = "PRL132_036001"
outdir = joinpath(project_dir, "fig5b_reproduction")
partial_dir = joinpath(outdir, "partial_dat")

if rank == 0
    ensure_dir(outdir)
    ensure_dir(partial_dir)
end

MPI.Barrier(comm)

# ---------------------------------------------------------
# Calculation parameters
# ---------------------------------------------------------
Nk = 64
T = 0.01
U = 0.86

# 初始测试可以先用 11 或 21 个点
mu_list = collect(range(0.0, 1.0, length=51))

# ARPACK parameters
nev = 4
eig_tol = 1e-6
eig_maxiter = 500

# Resume mode
resume = true

# Output files
partial_file = joinpath(partial_dir, @sprintf("partial_rank%04d.dat", rank))
final_file = joinpath(outdir, @sprintf("fig5b_gap_eigenvalues_Nk%d_nmu%d_T%s_U%s.dat",
                                       Nk, length(mu_list),
                                       float_to_tag(T),
                                       float_to_tag(U)))

# ---------------------------------------------------------
# Load existing partial data for resume
# ---------------------------------------------------------
local_rows = resume ? read_partial_dat(partial_file) : Dict{Int, Tuple{Float64, Float64, Float64}}()

# ---------------------------------------------------------
# Precompute eigensystem on each rank
# ---------------------------------------------------------
eig_data = precompute_eigensystem_periodic(Nk)

MPI.Barrier(comm)

# ---------------------------------------------------------
# Distribute mu points over MPI ranks
# ---------------------------------------------------------
for imu in 1:length(mu_list)
    if mod(imu - 1, nprocs) != rank
        continue
    end

    mu = mu_list[imu]

    if haskey(local_rows, imu)
        println("Rank $rank: imu=$imu, mu=$(round(mu, digits=4)) already done, skip.")
        flush(stdout)
        continue
    end

    println("="^72)
    println("Rank $rank: start imu=$imu / $(length(mu_list)), mu=$(round(mu, digits=4))")
    println("="^72)
    flush(stdout)

    lambda_s, lambda_t = compute_one_mu(
        eig_data,
        mu;
        T=T,
        U=U,
        nev=nev,
        eig_tol=eig_tol,
        eig_maxiter=eig_maxiter,
    )

    local_rows[imu] = (mu, lambda_s, lambda_t)

    write_partial_dat(
        partial_file,
        local_rows;
        Nk=Nk,
        T=T,
        U=U,
        rank=rank,
    )

    @printf("Rank %d: finished mu = %.6f, lambda_s = %.8e, lambda_t = %.8e\n",
            rank, mu, lambda_s, lambda_t)
    flush(stdout)
end

MPI.Barrier(comm)

# ---------------------------------------------------------
# Rank 0 merges all partial .dat files
# ---------------------------------------------------------
if rank == 0
    partial_files = [joinpath(partial_dir, @sprintf("partial_rank%04d.dat", r))
                     for r in 0:nprocs-1]

    merge_partial_dat(
        final_file,
        partial_files;
        mu_list=mu_list,
        Nk=Nk,
        T=T,
        U=U,
    )
end

MPI.Barrier(comm)

MPI.Finalize()