#!/usr/bin/env julia

# ============================================================
# Square-lattice Rashba superconductor
# Superconducting Edelstein effect
#
# MPI parallel version.
#
# Output:
#   data/rashba_lattice_edelstein_mpi.dat
#
# Tensor:
#   delta M_a = alpha_ab q_b
#
# Main Rashba Edelstein component:
#   alpha_yx : q_x -> M_y
# ============================================================

using MPI
using LinearAlgebra
using Printf
using Dates

BLAS.set_num_threads(1)

# ============================================================
# 0. MPI initialization
# ============================================================

MPI.Init()

const comm = MPI.COMM_WORLD
const rank = MPI.Comm_rank(comm)
const nprocs = MPI.Comm_size(comm)

# ============================================================
# 1. Parameters
# ============================================================

const t_hop = 1.0
const mu = -3.0
const Delta0 = 0.10
const temperature = 0.03

# k mesh
const Nk = 251

# Rashba SOC scan
const lambda_min = 0.0
const lambda_max = 0.60
const lambda_num = 61

# Constants, dimensionless units
const gs = 2.0
const muB = 1.0

# Degeneracy tolerance for K_nm
const degeneracy_eps = 1.0e-10

# Output
const data_dir = "data"
const output_file = joinpath(data_dir, "rashba_lattice_edelstein_mpi.dat")

# ============================================================
# 2. Pauli matrices
# ============================================================

const s0 = ComplexF64[
    1.0 + 0im  0.0 + 0im
    0.0 + 0im  1.0 + 0im
]

const sx = ComplexF64[
    0.0 + 0im  1.0 + 0im
    1.0 + 0im  0.0 + 0im
]

const sy = ComplexF64[
    0.0 + 0im   0.0 - 1im
    0.0 + 1im   0.0 + 0im
]

const sz = ComplexF64[
    1.0 + 0im   0.0 + 0im
    0.0 + 0im  -1.0 + 0im
]

const zero2 = zeros(ComplexF64, 2, 2)

# ============================================================
# 3. Small matrix helpers
# ============================================================

function block2x2(A::Matrix{ComplexF64}, B::Matrix{ComplexF64},
                  C::Matrix{ComplexF64}, D::Matrix{ComplexF64})
    M = zeros(ComplexF64, 4, 4)
    @views begin
        M[1:2, 1:2] .= A
        M[1:2, 3:4] .= B
        M[3:4, 1:2] .= C
        M[3:4, 3:4] .= D
    end
    return M
end

# ============================================================
# 4. Normal-state Rashba lattice Hamiltonian
# ============================================================

function h_normal(kx::Float64, ky::Float64, lambda_R::Float64)
    xi = -2.0 * t_hop * (cos(kx) + cos(ky)) - mu
    H = xi .* s0 .+
        lambda_R .* (sin(kx) .* sy .- sin(ky) .* sx)
    return Matrix{ComplexF64}(H)
end

function dh_dk(kx::Float64, ky::Float64, lambda_R::Float64, direction::Symbol)
    if direction == :x
        V = 2.0 * t_hop * sin(kx) .* s0 .+
            lambda_R * cos(kx) .* sy
    elseif direction == :y
        V = 2.0 * t_hop * sin(ky) .* s0 .-
            lambda_R * cos(ky) .* sx
    else
        error("direction must be :x or :y")
    end

    return Matrix{ComplexF64}(V)
end

# ============================================================
# 5. BdG Hamiltonian and Nambu operators
# ============================================================

function bdg_hamiltonian(kx::Float64, ky::Float64, lambda_R::Float64)
    Hk = h_normal(kx, ky, lambda_R)
    Hmk = h_normal(-kx, -ky, lambda_R)

    Delta = Delta0 .* (1im .* sy)

    HBdG = block2x2(
        Hk,
        Matrix{ComplexF64}(Delta),
        Matrix{ComplexF64}(Delta'),
        -conj.(Hmk),
    )

    return HBdG
end

function nambu_velocity(kx::Float64, ky::Float64, lambda_R::Float64, direction::Symbol)
    Ve = dh_dk(kx, ky, lambda_R, direction)
    Vh = -conj.(dh_dk(-kx, -ky, lambda_R, direction))

    Vbdg = block2x2(
        Ve,
        zero2,
        zero2,
        Vh,
    )

    return Vbdg
end

function nambu_spin(direction::Symbol)
    s = if direction == :x
        sx
    elseif direction == :y
        sy
    elseif direction == :z
        sz
    else
        error("spin direction must be :x, :y, or :z")
    end

    eta = block2x2(
        Matrix{ComplexF64}(s),
        zero2,
        zero2,
        -conj.(s),
    )

    return eta
end

const eta_ops = (
    nambu_spin(:x),
    nambu_spin(:y),
    nambu_spin(:z),
)

# ============================================================
# 6. Fermi function and response kernel
# ============================================================

@inline function fermi(E::Float64, beta::Float64)
    x = clamp(beta * E, -700.0, 700.0)
    return 1.0 / (exp(x) + 1.0)
end

@inline function fermi_derivative(E::Float64, beta::Float64)
    f = fermi(E, beta)
    return -beta * f * (1.0 - f)
end

function response_kernel!(K::Matrix{Float64}, E::Vector{Float64}, beta::Float64)
    nb = length(E)

    @inbounds for n in 1:nb
        En = E[n]
        fn = fermi(En, beta)

        for m in 1:nb
            Em = E[m]
            fm = fermi(Em, beta)

            denom = En - Em

            if abs(denom) > degeneracy_eps
                K[n, m] = (fn - fm) / denom
            else
                K[n, m] = fermi_derivative(0.5 * (En + Em), beta)
            end
        end
    end

    return nothing
end

# ============================================================
# 7. k mesh distribution over MPI ranks
# ============================================================

@inline function linear_index_to_k(idx::Int)
    # idx = 1, ..., Nk*Nk
    ix = div(idx - 1, Nk) + 1
    iy = mod(idx - 1, Nk) + 1

    dk = 2.0 * pi / Nk

    # midpoint mesh on [-pi, pi)
    kx = -pi + (ix - 0.5) * dk
    ky = -pi + (iy - 0.5) * dk

    return kx, ky
end

function lambda_grid()
    if lambda_num == 1
        return [lambda_min]
    end

    return collect(range(lambda_min, lambda_max, length=lambda_num))
end

# ============================================================
# 8. Local calculation for one lambda_R
# ============================================================

function local_accumulate_for_lambda(lambda_R::Float64)
    beta = 1.0 / temperature

    # alpha accumulator: 3 spin components x 2 q directions
    acc_total = zeros(Float64, 3, 2)
    acc_intra = zeros(Float64, 3, 2)
    acc_inter = zeros(Float64, 3, 2)

    nb = 4
    K = zeros(Float64, nb, nb)

    total_k = Nk * Nk

    # MPI distribution over k points
    for idx in (rank + 1):nprocs:total_k
        kx, ky = linear_index_to_k(idx)

        HBdG = bdg_hamiltonian(kx, ky, lambda_R)

        eig = eigen(Hermitian(HBdG))
        E = Vector{Float64}(eig.values)
        U = Matrix{ComplexF64}(eig.vectors)

        response_kernel!(K, E, beta)

        Udag = U'

        eta_band = (
            Udag * eta_ops[1] * U,
            Udag * eta_ops[2] * U,
            Udag * eta_ops[3] * U,
        )

        vx_op = nambu_velocity(kx, ky, lambda_R, :x)
        vy_op = nambu_velocity(kx, ky, lambda_R, :y)

        v_band = (
            Udag * vx_op * U,
            Udag * vy_op * U,
        )

        @inbounds for ia in 1:3
            eta_b = eta_band[ia]

            for ib in 1:2
                v_b = v_band[ib]

                total_val = 0.0
                intra_val = 0.0
                inter_val = 0.0

                for n in 1:nb
                    for m in 1:nb
                        # eta_nm * v_mn * K_nm
                        val = real(eta_b[n, m] * v_b[m, n]) * K[n, m]

                        total_val += val

                        if n == m
                            intra_val += val
                        else
                            inter_val += val
                        end
                    end
                end

                acc_total[ia, ib] += total_val
                acc_intra[ia, ib] += intra_val
                acc_inter[ia, ib] += inter_val
            end
        end
    end

    return acc_total, acc_intra, acc_inter
end

# ============================================================
# 9. MPI allreduce helper
# ============================================================

function allreduce_sum_matrix(local_mat::Matrix{Float64})
    global_mat = similar(local_mat)
    MPI.Allreduce!(local_mat, global_mat, +, comm)
    return global_mat
end

# ============================================================
# 10. Main calculation
# ============================================================

function main()
    lambdas = lambda_grid()

    if rank == 0
        mkpath(data_dir)

        @printf("============================================================\n")
        @printf("Rashba lattice superconducting Edelstein effect\n")
        @printf("Julia MPI calculation\n")
        @printf("============================================================\n")
        @printf("MPI processes     = %d\n", nprocs)
        @printf("t                 = %.8f\n", t_hop)
        @printf("mu                = %.8f\n", mu)
        @printf("Delta0            = %.8f\n", Delta0)
        @printf("T                 = %.8f\n", temperature)
        @printf("Nk                = %d x %d\n", Nk, Nk)
        @printf("lambda_R range    = [%.8f, %.8f], N = %d\n",
                lambda_min, lambda_max, lambda_num)
        @printf("output            = %s\n", output_file)
        @printf("============================================================\n")
        flush(stdout)

        open(output_file, "w") do io
            println(io, "# Square-lattice Rashba superconductor")
            println(io, "# H(k) = xi(k) s0 + lambda_R [sin(kx) sy - sin(ky) sx]")
            println(io, "# xi(k) = -2t [cos(kx)+cos(ky)] - mu")
            println(io, "# Delta = Delta0 i sy")
            println(io, "# Response: delta M_a = alpha_ab q_b")
            println(io, "# Units: a = hbar = kB = muB = 1")
            println(io, "#")
            @printf(io, "# t = %.16e\n", t_hop)
            @printf(io, "# mu = %.16e\n", mu)
            @printf(io, "# Delta0 = %.16e\n", Delta0)
            @printf(io, "# temperature = %.16e\n", temperature)
            @printf(io, "# Nk = %d\n", Nk)
            @printf(io, "# nprocs = %d\n", nprocs)
            println(io, "#")
            println(io, "# columns:")
            println(io, "# lambda_R alpha_xx alpha_xy alpha_yx alpha_yy alpha_zx alpha_zy alpha_yx_intra alpha_yx_inter")
        end
    end

    MPI.Barrier(comm)

    t0 = time()

    for (iλ, λ) in enumerate(lambdas)
        local_total, local_intra, local_inter = local_accumulate_for_lambda(λ)

        global_total_raw = allreduce_sum_matrix(local_total)
        global_intra_raw = allreduce_sum_matrix(local_intra)
        global_inter_raw = allreduce_sum_matrix(local_inter)

        # For BZ = [-pi, pi]^2,
        # ∫BZ d^2k/(2π)^2 equals uniform average over k mesh.
        #
        # Formula:
        # alpha_ab = (gs*muB/8) * average_k sum_nm Re[eta_nm v_mn] K_nm
        prefactor = gs * muB / 8.0
        norm = 1.0 / (Nk * Nk)

        alpha_total = prefactor .* norm .* global_total_raw
        alpha_intra = prefactor .* norm .* global_intra_raw
        alpha_inter = prefactor .* norm .* global_inter_raw

        if rank == 0
            αxx = alpha_total[1, 1]
            αxy = alpha_total[1, 2]
            αyx = alpha_total[2, 1]
            αyy = alpha_total[2, 2]
            αzx = alpha_total[3, 1]
            αzy = alpha_total[3, 2]

            αyx_intra = alpha_intra[2, 1]
            αyx_inter = alpha_inter[2, 1]

            open(output_file, "a") do io
                @printf(io,
                    "%.16e %.16e %.16e %.16e %.16e %.16e %.16e %.16e %.16e\n",
                    λ, αxx, αxy, αyx, αyy, αzx, αzy, αyx_intra, αyx_inter
                )
            end

            @printf("[%4d/%4d] lambda_R = %.8f | alpha_yx = %+ .8e | intra = %+ .8e | inter = %+ .8e\n",
                    iλ, length(lambdas), λ, αyx, αyx_intra, αyx_inter)
            flush(stdout)
        end
    end

    MPI.Barrier(comm)

    if rank == 0
        elapsed = time() - t0
        @printf("============================================================\n")
        @printf("Finished. Elapsed time = %.2f s\n", elapsed)
        @printf("Data saved to: %s\n", output_file)
        @printf("============================================================\n")
    end
end

main()

MPI.Finalize()