(* ::Package:: *)

(* Paclet Info File *)

(* created 2010/12/02*)

Paclet[
    Name -> "Pfaffian",
    Version -> "0.0.1",
    MathematicaVersion -> "8+",
    Extensions -> 
        {
            {"Documentation", Language -> "English"}
        }
]


