(* ::Package:: *)

(* Code by Robert W. Cherng, http://physics.harvard.edu/~cherng/programs.html *)
(* Modified by Everett You *)
BeginPackage["Pfaffian`"];
Pf::usage="Pf[\!\(\*StyleBox[\"m\", \"TI\"]\)] gives the pfaffian of the screw symmetric matrix \!\(\*StyleBox[\"m\", \"TI\"]\). ";
Begin["`Private`"];
Pf[A_]:=
	Switch[Length[A],
		0,1,
		_?OddQ,0,
		_?EvenQ,
		If[MatchQ[A,{{_?NumericQ...}...}],
			nPf[A],
			xPf[A,1]
		]
	];
(* analytic *)
xPf[A_,p0_]:=
Module[{A0,n,pivot,sign=1,A1,p1},
	n=Length[A]/2;
	If[n==1,A[[1,2]],
		A0=A;
		pivot=First[Ordering[Abs[A0[[2 n-1,All]]],-1]];
		If[pivot!=2 n,
			A0[[{pivot,2 n},All]]=A0[[{2 n,pivot},All]];
			A0[[All,{pivot,2 n}]]=A0[[All,{2 n,pivot}]];
			sign=-1;
		];
		p1=A0[[2 n-1,2 n]];
		A1=p1 A0[[1;;2 n-2,1;;2 n-2]];
		A1+=(#-Transpose[#])&@
			Outer[Times,A0[[1;;2 n-2,2 n]],A0[[1;;2 n-2,2 n-1]]];
		A1/=p0;
		sign xPf[A1,p1]
	]
];
(* numerics *)
nPf[A_]:=Det[#1](Times@@Diagonal[#2,1][[1;;-1;;2]])&@@SchurDecomposition[A];
End[];
EndPackage[];
