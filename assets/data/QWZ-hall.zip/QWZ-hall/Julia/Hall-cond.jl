using Distributed,LinearAlgebra
@everywhere begin
    using LinearAlgebra
    
    # --- 物理参数定义 ---
    const dp = Float64
    const im_unit = 1im
    const t1 = 1.0
    const ax = 1.0
    const ay = 1.0
    const Nk = 500  # 减小一点以加快演示速度
    const omega = 1e-8
    
    """构建哈密顿量矩阵"""
    function get_hamiltonian(kx, ky, m0, mu)
        h0 = m0 - t1 * (cos(kx) + cos(ky)) - mu
        # H = h0*sigma_z + ax*sin(kx)*sigma_x + ay*sin(ky)*sigma_y
        H = zeros(Complex{Float64}, 2, 2)
        H[1, 1] = h0
        H[2, 2] = -h0
        H[1, 2] = ax * sin(kx) - im_unit * ay * sin(ky)
        H[2, 1] = ax * sin(kx) + im_unit * ay * sin(ky)
        return H
    end

    """解析法计算 Berry 曲率"""
    function calculate_berry_curvature(kx, ky, m0, mu, ind_band=1)
        H = get_hamiltonian(kx, ky, m0, mu)
        # 对角化
        vals, vecs = eigen(Hermitian(H))
        
        # 解析偏导数矩阵
        dHdkx = [t1*sin(kx)           ax*cos(kx);
                 ax*cos(kx)          -t1*sin(kx)]
                 
        dHdky = [t1*sin(ky)          -im_unit*ay*cos(ky);
                 im_unit*ay*cos(ky)  -t1*sin(ky)]
        
        curvature = 0.0
        n_bands = 2
        for j in 1:n_bands
            if j != ind_band
                # 分子: <n|dH/dkx|j> * <j|dH/dky|n>
                num = (vecs[:, ind_band]' * dHdkx * vecs[:, j]) * (vecs[:, j]' * dHdky * vecs[:, ind_band])
                # 分母: (En - Ej)^2
                den = (vals[ind_band] - vals[j])^2 + omega
                curvature += 2.0 * imag(num / den)
            end
        end
        return curvature
    end

    """对整个布里渊区积分计算单个 m0 下的电导"""
    function calculate_hall_conductance(m0, mu)
        total_curvature = 0.0
        dk = pi / Nk
        # 遍历布里渊区 [-pi, pi)
        for ikx in -Nk:(Nk-1)
            kx = pi * ikx / Nk
            for iky in -Nk:(Nk-1)
                ky = pi * iky / Nk
                total_curvature += calculate_berry_curvature(kx, ky, m0, mu) * (dk^2)
            end
        end
        return total_curvature / (2π)
    end
end

# --- 主程序 ---
function main()
    num_mu = 100
    mu_max = 3.0
    m0_list = collect(range(-mu_max, mu_max, length=num_mu))
    mu_val = 0.0 # 固定化学势
    
    println("Starting parallel calculation on $(nprocs()) processes...")
    
    # 使用 @distributed 并行循环
    # pmap 也是一种很好的选择，可以自动处理负载均衡
    results = pmap(m0 -> calculate_hall_conductance(m0, mu_val), m0_list)
    
    # 保存数据
    open("Hall-mu_julia.dat", "w") do f
        for i in 1:num_mu
            println(f, "$(m0_list[i])    $(results[i])")
        end
    end
    println("Calculation finished. Data saved to Hall-mu_julia.dat")
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end