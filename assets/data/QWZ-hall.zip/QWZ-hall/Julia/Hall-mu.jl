using Distributed,LinearAlgebra

# 启动并行进程（如果在命令行已用 -p 启动则此行不生效）
if nprocs() == 1
    addprocs(exeflags="--project")
end

@everywhere begin
    using LinearAlgebra

    # 模型参数
    const t1 = 1.0
    const ax = 1.0
    const ay = 1.0
    const Nk = 100  # FHS算法在较小的Nk下也能非常精确
    const T = 0.001 # 温度

    """构建哈密顿量"""
    function get_H(kx, ky, m0)
        h0 = m0 - t1 * (cos(kx) + cos(ky))
        return Hermitian([ h0                  ax*sin(kx) - 1im*ay*sin(ky);
                           ax*sin(kx) + 1im*ay*sin(ky)  -h0 ])
    end

    """费米分布"""
    fermi(E, mu, T) = T < 1e-7 ? (E <= mu ? 1.0 : 0.0) : 1.0 / (exp((E - mu) / T) + 1.0)

    """计算单个 mu 下的霍尔电导 (FHS 算法)"""
    function calculate_hall_fhs(m0, mu)
        # 1. 预计算整个 BZ 的能带和波函数
        # 增加一行一列用于处理周期性边界条件 (Nk+1)
        energies = [zeros(2) for i in 1:Nk+1, j in 1:Nk+1]
        wavefuncs = [zeros(ComplexF64, 2, 2) for i in 1:Nk+1, j in 1:Nk+1]
        
        dk = 2π / Nk
        for i in 1:Nk+1, j in 1:Nk+1
            kx = -π + (i-1) * dk
            ky = -π + (j-1) * dk
            vals, vecs = eigen(get_H(kx, ky, m0))
            energies[i, j] = vals
            wavefuncs[i, j] = vecs # vecs[:, n] 是第 n 条能带
        end

        total_sigma = 0.0
        # 2. 对每个网格计算 Berry Flux
        for i in 1:Nk, j in 1:Nk
            for n in 1:2
                # 计算该点在该能带的占据率 (取网格左下角能量)
                f = fermi(energies[i, j][n], mu, T)
                if f < 1e-4 continue end 

                # FHS Link variables: U = <psi(k)|psi(k+dk)> / |<...>|
                v1 = wavefuncs[i, j][:, n]
                v2 = wavefuncs[i+1, j][:, n]
                v3 = wavefuncs[i+1, j+1][:, n]
                v4 = wavefuncs[i, j+1][:, n]

                U1 = dot(v1, v2) / abs(dot(v1, v2))
                U2 = dot(v2, v3) / abs(dot(v2, v3))
                U3 = dot(v3, v4) / abs(dot(v3, v4))
                U4 = dot(v4, v1) / abs(dot(v4, v1))

                # 网格通量: LF = log(U1*U2*U3*U4)
                # imag(log(...)) 保证了结果在 (-pi, pi] 之间
                flux = imag(log(U1 * U2 * U3 * U4))
                total_sigma += f * flux
            end
        end
        return total_sigma / (2π)
    end
end

# --- 主程序 ---
function main()
    m0_val = 1.0  # 拓扑非平庸相
    mu_list = collect(range(-3.0, 3.0, length=300))
    
    println("Using FHS algorithm to scan mu with $(nprocs()) workers...")
    
    # 进度监控与并行执行
    results = pmap(mu -> calculate_hall_fhs(m0_val, mu), mu_list)
    
    # 输出结果
    filename = "Hall_vs_mu.dat"
    open(filename, "w") do io
        for (m, s) in zip(mu_list, results)
            println(io, "$(rpad(m, 10))    $(s)")
        end
    end
    println("Calculation complete. Data saved to $filename")
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end