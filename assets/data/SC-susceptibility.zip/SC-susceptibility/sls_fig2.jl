#!/usr/bin/env julia
# =========================================================
# SLS Fig. 2 data calculation, Julia parallel version
#
# No plotting in this script.
#
# Parallelization:
#   - uses @sync @distributed
#   - transition line: parallel over delta_mu points
#   - chi(qx,qy) map: parallel over q-grid points
#
# Run:
#   julia -p 8 sls_fig2_parallel_dat_only.jl
#
# Output:
#   sls_fig2_julia_parallel/
#   ├── fig2_phase_boundary.dat
#   └── fig2_chi_map.dat
#
# Data 1: fig2_phase_boundary.dat
#   columns:
#   delta_mu  T_c  delta_mu/Tc0  T_c/Tc0  qx  qy  q0  max_chi  status_code
#
# Data 2: fig2_chi_map.dat
#   columns:
#   qx  qy  chi
#
# status_code:
#   0 = ok
#   1 = no_transition_above_Tmin
#   2 = transition_above_Tmax
# =========================================================

using Distributed

# =========================================================
# 0. Parallel startup
# =========================================================
# Recommended:
#   julia -p 8 sls_fig2_parallel_dat_only.jl
#
# If you want the script itself to add workers, set AUTO_ADD_PROCS=true.
const AUTO_ADD_PROCS = false
const N_WORKERS_TO_ADD = 8

if AUTO_ADD_PROCS && nprocs() == 1
    addprocs(N_WORKERS_TO_ADD)
end

@everywhere begin
    using Printf
    using SharedArrays

    # =====================================================
    # 1. Parameters
    # =====================================================
    struct Params
        # SLS model parameters
        t::Float64
        mu::Float64
        phi::Float64
        u::Float64

        # Mesh for Tc(delta_mu) and q0(delta_mu)
        Nk_phase::Int
        Nq_line::Int
        q_line_max::Float64

        # delta_mu range in units of Tc0
        delta_mu_over_Tc0_max::Float64
        N_delta::Int

        # Bisection parameters
        T_min::Float64
        T_max::Float64
        T_tol::Float64
        max_bisect_iter::Int

        # Mesh for Fig. 2(c)-like chi(q) map
        Nk_map::Int
        Nq_map::Int
        q_map_bz_scale::Float64

        # Point used for Fig. 2(c)
        fig2c_delta_mu::Float64
        fig2c_T::Float64

        # Output
        outdir::String
    end


    # =====================================================
    # 2. Geometry
    # =====================================================
    @inline function bz_area()
        return 8.0 * pi^2 / sqrt(3.0)
    end

    @inline function in_hexagon(kx::Float64, ky::Float64, scale::Float64)
        # Hexagon with vertices:
        #   (±4π/3, 0), (±2π/3, ±2π/√3)
        #
        # Equivalent inequalities:
        #   |ky| <= 2π/√3
        #   |√3 kx + ky| <= 4π/√3
        #   |√3 kx - ky| <= 4π/√3
        a = 2.0 * pi / sqrt(3.0) * scale
        b = 4.0 * pi / sqrt(3.0) * scale

        return (
            abs(ky) <= a + 1e-14 &&
            abs(sqrt(3.0) * kx + ky) <= b + 1e-14 &&
            abs(sqrt(3.0) * kx - ky) <= b + 1e-14
        )
    end

    @inline function c3_dot_0(kx::Float64, ky::Float64)
        return kx
    end

    @inline function c3_dot_1(kx::Float64, ky::Float64)
        return -0.5 * kx + 0.5 * sqrt(3.0) * ky
    end

    @inline function c3_dot_2(kx::Float64, ky::Float64)
        return -0.5 * kx - 0.5 * sqrt(3.0) * ky
    end


    # =====================================================
    # 3. SLS dispersion
    # =====================================================
    @inline function xi_eta(kx::Float64, ky::Float64, eta::Int, p::Params)
        # xi_{eta,k} =
        #   -t sum_{n=0}^{2} cos(k · C3^n xhat - eta * phi) - mu
        total =
            cos(c3_dot_0(kx, ky) - eta * p.phi) +
            cos(c3_dot_1(kx, ky) - eta * p.phi) +
            cos(c3_dot_2(kx, ky) - eta * p.phi)

        return -p.t * total - p.mu
    end

    @inline function epsilon_eta(kx::Float64, ky::Float64, eta::Int, delta_mu::Float64, p::Params)
        # epsilon_{eta,k} = xi_{eta,k} - eta * delta_mu / 2
        return xi_eta(kx, ky, eta, p) - 0.5 * eta * delta_mu
    end


    # =====================================================
    # 4. Fermi function and kernel
    # =====================================================
    @inline function fermi(eps::Float64, T::Float64)
        x = clamp(eps / T, -700.0, 700.0)
        return 1.0 / (exp(x) + 1.0)
    end

    @inline function pairing_kernel(eps1::Float64, eps2::Float64, T::Float64)
        # K = [1 - f(eps1) - f(eps2)] / [eps1 + eps2].
        #
        # If eps1 + eps2 -> 0:
        #   K -> beta / [4 cosh^2(beta eps1 / 2)].
        denom = eps1 + eps2

        if abs(denom) > 1e-12
            return (1.0 - fermi(eps1, T) - fermi(eps2, T)) / denom
        else
            beta = 1.0 / T
            arg = 0.5 * beta * eps1

            if abs(arg) > 350.0
                return 0.0
            else
                return beta / (4.0 * cosh(arg)^2)
            end
        end
    end


    # =====================================================
    # 5. Mesh generation
    # =====================================================
    function make_bz_kmesh(Nk::Int)
        # Bounding box of the full BZ.
        kxmin = -4.0 * pi / 3.0
        kxmax =  4.0 * pi / 3.0
        kymin = -2.0 * pi / sqrt(3.0)
        kymax =  2.0 * pi / sqrt(3.0)

        kx_grid = collect(range(kxmin, kxmax; length=Nk))
        ky_grid = collect(range(kymin, kymax; length=Nk))

        kx_vec = Float64[]
        ky_vec = Float64[]

        sizehint!(kx_vec, Nk * Nk)
        sizehint!(ky_vec, Nk * Nk)

        for kx in kx_grid
            for ky in ky_grid
                if in_hexagon(kx, ky, 1.0)
                    push!(kx_vec, kx)
                    push!(ky_vec, ky)
                end
            end
        end

        return kx_vec, ky_vec
    end

    function make_q_line(p::Params)
        qx_line = collect(range(0.0, p.q_line_max; length=p.Nq_line))
        qy_line = zeros(Float64, p.Nq_line)

        return qx_line, qy_line
    end

    function make_q_grid_for_map(p::Params)
        # Bounding box of the scaled hexagon.
        scale = p.q_map_bz_scale

        qxmin = -4.0 * pi / 3.0 * scale
        qxmax =  4.0 * pi / 3.0 * scale
        qymin = -2.0 * pi / sqrt(3.0) * scale
        qymax =  2.0 * pi / sqrt(3.0) * scale

        qx_grid = collect(range(qxmin, qxmax; length=p.Nq_map))
        qy_grid = collect(range(qymin, qymax; length=p.Nq_map))

        return qx_grid, qy_grid
    end


    # =====================================================
    # 6. chi(q) calculation
    # =====================================================
    function chi_of_q(
        qx::Float64,
        qy::Float64,
        delta_mu::Float64,
        T::Float64,
        kx_vec::Vector{Float64},
        ky_vec::Vector{Float64},
        p::Params,
    )
        nk = length(kx_vec)
        s = 0.0

        @inbounds for i in 1:nk
            kx = kx_vec[i]
            ky = ky_vec[i]

            eps_plus = epsilon_eta(kx, ky, +1, delta_mu, p)
            eps_minus_pair = epsilon_eta(-kx + qx, -ky + qy, -1, delta_mu, p)

            s += pairing_kernel(eps_plus, eps_minus_pair, T)
        end

        # integral_BZ d^2k/(2π)^2 ≈ area_BZ/(2π)^2 * mean_BZ
        weight = 2 * bz_area() / (2.0 * pi)^2

        return weight * s / nk
    end

    function max_chi_on_q_line(
        delta_mu::Float64,
        T::Float64,
        kx_vec::Vector{Float64},
        ky_vec::Vector{Float64},
        qx_line::Vector{Float64},
        qy_line::Vector{Float64},
        p::Params,
    )
        best_chi = -Inf
        best_qx = 0.0
        best_qy = 0.0

        @inbounds for iq in eachindex(qx_line)
            qx = qx_line[iq]
            qy = qy_line[iq]

            chi = chi_of_q(qx, qy, delta_mu, T, kx_vec, ky_vec, p)

            if chi > best_chi
                best_chi = chi
                best_qx = qx
                best_qy = qy
            end
        end

        return best_chi, best_qx, best_qy, abs(best_qx)
    end

    function transition_value(
        delta_mu::Float64,
        T::Float64,
        kx_vec::Vector{Float64},
        ky_vec::Vector{Float64},
        qx_line::Vector{Float64},
        qy_line::Vector{Float64},
        p::Params,
    )
        max_chi, qx, qy, q0 = max_chi_on_q_line(
            delta_mu, T, kx_vec, ky_vec, qx_line, qy_line, p
        )

        return 1.0 / p.u - max_chi, max_chi, qx, qy, q0
    end

    function solve_Tc_for_delta(
        delta_mu::Float64,
        kx_vec::Vector{Float64},
        ky_vec::Vector{Float64},
        qx_line::Vector{Float64},
        qy_line::Vector{Float64},
        p::Params,
    )
        f_low, max_low, qx_low, qy_low, q0_low = transition_value(
            delta_mu, p.T_min, kx_vec, ky_vec, qx_line, qy_line, p
        )

        f_high, max_high, qx_high, qy_high, q0_high = transition_value(
            delta_mu, p.T_max, kx_vec, ky_vec, qx_line, qy_line, p
        )

        # status_code:
        #   0 = ok
        #   1 = no_transition_above_Tmin
        #   2 = transition_above_Tmax
        if f_low > 0.0
            return (
                Tc=NaN,
                qx=NaN,
                qy=NaN,
                q0=NaN,
                max_chi=max_low,
                status_code=1,
            )
        end

        if f_high < 0.0
            return (
                Tc=NaN,
                qx=NaN,
                qy=NaN,
                q0=NaN,
                max_chi=max_high,
                status_code=2,
            )
        end

        T_left = p.T_min
        T_right = p.T_max

        best_T = 0.5 * (T_left + T_right)
        best_max = NaN
        best_qx = NaN
        best_qy = NaN
        best_q0 = NaN

        for _ in 1:p.max_bisect_iter
            T_mid = 0.5 * (T_left + T_right)

            f_mid, max_mid, qx_mid, qy_mid, q0_mid = transition_value(
                delta_mu, T_mid, kx_vec, ky_vec, qx_line, qy_line, p
            )

            best_T = T_mid
            best_max = max_mid
            best_qx = qx_mid
            best_qy = qy_mid
            best_q0 = q0_mid

            if abs(f_mid) < p.T_tol
                break
            end

            if f_mid > 0.0
                T_right = T_mid
            else
                T_left = T_mid
            end
        end

        return (
            Tc=best_T,
            qx=best_qx,
            qy=best_qy,
            q0=best_q0,
            max_chi=best_max,
            status_code=0,
        )
    end
end


# =========================================================
# 7. Main-process packages
# =========================================================
using Printf
using SharedArrays


# =========================================================
# 8. Transition line, parallel over delta_mu
# =========================================================
function compute_transition_line_parallel(p::Params)
    println("Preparing k and q meshes for transition-line calculation ...")
    kx_vec, ky_vec = make_bz_kmesh(p.Nk_phase)
    qx_line, qy_line = make_q_line(p)

    println("Number of processes: ", nprocs())
    println("Number of workers:   ", nworkers())
    println("Number of k points inside BZ: ", length(kx_vec))
    println("Number of q points along +x:  ", length(qx_line))

    println("\nSolving Tc0 at delta_mu=0 sequentially ...")
    res0 = solve_Tc_for_delta(0.0, kx_vec, ky_vec, qx_line, qy_line, p)
    Tc0 = res0.Tc

    if !isfinite(Tc0)
        error("Failed to determine Tc0. Adjust u, T_min, T_max, or mesh parameters.")
    end

    @printf("Tc0 = %.10f\n", Tc0)

    delta_mu_list = collect(range(
        0.0,
        p.delta_mu_over_Tc0_max * Tc0;
        length=p.N_delta,
    ))

    # columns:
    # delta_mu, Tc, delta_mu/Tc0, Tc/Tc0, qx, qy, q0, max_chi, status_code
    data = SharedArray{Float64}((p.N_delta, 9))

    println("\nStart @distributed transition-line calculation ...")

    @sync @distributed for i in 1:p.N_delta
        delta_mu = delta_mu_list[i]

        res = solve_Tc_for_delta(
            delta_mu,
            kx_vec,
            ky_vec,
            qx_line,
            qy_line,
            p,
        )

        data[i, 1] = delta_mu
        data[i, 2] = res.Tc
        data[i, 3] = delta_mu / Tc0
        data[i, 4] = isfinite(res.Tc) ? res.Tc / Tc0 : NaN
        data[i, 5] = res.qx
        data[i, 6] = res.qy
        data[i, 7] = res.q0
        data[i, 8] = res.max_chi
        data[i, 9] = res.status_code

        @printf(
            "finished %4d / %4d, delta_mu/Tc0 = %.4f, Tc/Tc0 = %.6f, q0 = %.6f, status = %d\n",
            i,
            p.N_delta,
            data[i, 3],
            data[i, 4],
            data[i, 7],
            Int(data[i, 9]),
        )
        flush(stdout)
    end

    return Tc0, Array(data)
end


# =========================================================
# 9. Fig. 2(c)-like chi(q) map, parallel over q-grid points
# =========================================================
function compute_chi_map_parallel(p::Params)
    println("\nPreparing chi(q) map calculation ...")
    kx_vec, ky_vec = make_bz_kmesh(p.Nk_map)
    qx_grid, qy_grid = make_q_grid_for_map(p)

    chi_map = SharedArray{Float64}((p.Nq_map, p.Nq_map))
    fill!(chi_map, NaN)

    total = p.Nq_map * p.Nq_map

    println("Number of k points inside BZ: ", length(kx_vec))
    println("q-grid size: ", p.Nq_map, " × ", p.Nq_map)
    println("Start @distributed chi-map calculation ...")

    @sync @distributed for idx in 1:total
        ix = div(idx - 1, p.Nq_map) + 1
        iy = mod(idx - 1, p.Nq_map) + 1

        qx = qx_grid[ix]
        qy = qy_grid[iy]

        if in_hexagon(qx, qy, p.q_map_bz_scale)
            chi_map[ix, iy] = chi_of_q(
                qx,
                qy,
                p.fig2c_delta_mu,
                p.fig2c_T,
                kx_vec,
                ky_vec,
                p,
            )
        else
            chi_map[ix, iy] = NaN
        end
    end

    return qx_grid, qy_grid, Array(chi_map)
end


# =========================================================
# 10. Save data
# =========================================================
function save_transition_data(data::Matrix{Float64}, p::Params)
    mkpath(p.outdir)

    file = joinpath(p.outdir, "fig2_phase_boundary.dat")

    open(file, "w") do io
        println(io, "# SLS Fig. 2 transition line from 1/u - max_q chi(q) = 0")
        println(io, "# Model:")
        println(io, "#   epsilon_eta(k) = xi_eta(k) - eta * delta_mu / 2")
        println(io, "#   xi_eta(k) = -t * sum_n cos(k·C3^n xhat - eta*phi) - mu")
        println(io, "# Parameters:")
        println(io, "#   t   = $(p.t)")
        println(io, "#   mu  = $(p.mu)")
        println(io, "#   phi = $(p.phi)")
        println(io, "#   u   = $(p.u)")
        println(io, "#   Nk_phase  = $(p.Nk_phase)")
        println(io, "#   Nq_line   = $(p.Nq_line)")
        println(io, "#   q_line_max = $(p.q_line_max)")
        println(io, "#   delta_mu_over_Tc0_max = $(p.delta_mu_over_Tc0_max)")
        println(io, "#   N_delta = $(p.N_delta)")
        println(io, "# Columns:")
        println(io, "#   delta_mu  T_c  delta_mu/Tc0  T_c/Tc0  qx  qy  q0  max_chi  status_code")
        println(io, "# status_code: 0=ok, 1=no_transition_above_Tmin, 2=transition_above_Tmax")

        for i in 1:size(data, 1)
            @printf(
                io,
                "%.16e  %.16e  %.16e  %.16e  %.16e  %.16e  %.16e  %.16e  %.0f\n",
                data[i, 1],
                data[i, 2],
                data[i, 3],
                data[i, 4],
                data[i, 5],
                data[i, 6],
                data[i, 7],
                data[i, 8],
                data[i, 9],
            )
        end
    end

    println("Transition data saved to: ", file)
    return file
end

function save_chi_map_data(qx_grid::Vector{Float64}, qy_grid::Vector{Float64}, chi_map::Matrix{Float64}, p::Params)
    mkpath(p.outdir)

    file = joinpath(p.outdir, "fig2_chi_map.dat")

    open(file, "w") do io
        println(io, "# SLS Fig. 2(c)-like pairing susceptibility map")
        println(io, "# chi(q)=integral_BZ d^2k/(2pi)^2 [1-f(eps_+,k)-f(eps_-,-k+q)]/[eps_+,k+eps_-,-k+q]")
        println(io, "# Parameters:")
        println(io, "#   delta_mu = $(p.fig2c_delta_mu)")
        println(io, "#   T        = $(p.fig2c_T)")
        println(io, "#   Nk_map   = $(p.Nk_map)")
        println(io, "#   Nq_map   = $(p.Nq_map)")
        println(io, "#   q_map_bz_scale = $(p.q_map_bz_scale)")
        println(io, "# Columns:")
        println(io, "#   qx  qy  chi")

        for ix in eachindex(qx_grid)
            for iy in eachindex(qy_grid)
                @printf(
                    io,
                    "%.16e  %.16e  %.16e\n",
                    qx_grid[ix],
                    qy_grid[iy],
                    chi_map[ix, iy],
                )
            end
        end
    end

    println("Chi-map data saved to: ", file)
    return file
end


# =========================================================
# 11. Main workflow
# =========================================================
function run_calculation(p::Params; do_transition::Bool=true, do_chimap::Bool=true)
    mkpath(p.outdir)

    if do_transition
        Tc0, data = compute_transition_line_parallel(p)
        save_transition_data(data, p)
        @printf("Finished transition line. Tc0 = %.10f\n", Tc0)
    end

    if do_chimap
        qx_grid, qy_grid, chi_map = compute_chi_map_parallel(p)
        save_chi_map_data(qx_grid, qy_grid, chi_map, p)

        idx = argmax(replace(chi_map, NaN => -Inf))
        @printf(
            "Max chi-map value: chi = %.8e, qx = %.8f, qy = %.8f\n",
            chi_map[idx],
            qx_grid[idx[1]],
            qy_grid[idx[2]],
        )
    end

    return nothing
end


# =========================================================
# 12. Final call
# =========================================================
if abspath(PROGRAM_FILE) == @__FILE__
    params = Params(
        1.0,                         # t
        -0.65,                       # mu
        -0.2 * pi,                   # phi
        0.596,                       # u

        201,                         # Nk_phase
        201,                         # Nq_line
        0.70,                        # q_line_max

        3.0,                         # delta_mu_over_Tc0_max
        201,                          # N_delta

        1.0e-4,                      # T_min
        0.40,                        # T_max
        2.0e-4,                      # T_tol
        35,                          # max_bisect_iter

        201,                         # Nk_map
        201,                         # Nq_map
        0.20,                        # q_map_bz_scale

        0.35,                        # fig2c_delta_mu
        0.08,                        # fig2c_T

        "sls_fig2_julia_parallel",   # outdir
    )

    # Calculation switches.
    DO_TRANSITION = true
    DO_CHIMAP = true

    run_calculation(params; do_transition=DO_TRANSITION, do_chimap=DO_CHIMAP)
end
