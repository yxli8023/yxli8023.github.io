Nonunitary-pairing magnetization demonstration
================================================

This package contains a pedagogical square-lattice BdG example showing how
a nonunitary equal-spin triplet gap can generate a finite electronic spin
magnetization.

Files
-----
1. nonunitary_magnetization_calculation.py
   Performs the calculation and saves all numerical data.

2. nonunitary_magnetization_plot.py
   Reads the saved data and creates the figures.

Run
---
python nonunitary_magnetization_calculation.py
python nonunitary_magnetization_plot.py

Model
-----
Normal-state band:
  xi_k = -2t(cos kx + cos ky) - 4t2 cos kx cos ky - mu.

Equal-spin chiral p-wave gaps:
  Delta_upup(k,T)     = Delta(T)[sin(kx)+i sin(ky)]
  Delta_downdown(k,T) = r Delta(T)[sin(kx)+i sin(ky)]

r = 1 is unitary.
0 <= r < 1 is nonunitary.
r = 0 is the maximally nonunitary, single-spin-pairing limit.

The nonunitary gap vector is
  q_Delta,z(k) = 1/2 (|Delta_upup(k)|^2 - |Delta_downdown(k)|^2).

The electronic magnetization is evaluated from the BdG occupations:
  n_{k,sigma} = 1/2[1 - xi_k/E_{k,sigma} tanh(E_{k,sigma}/2T)]
  M_z = mu_B/N sum_k(n_{k,up} - n_{k,down}).

The chemical potential is solved at every temperature so that the total
particle density remains fixed.

Scope
-----
This is a consequence demonstration: it assumes a nonunitary gap and
calculates the resulting pair-spin polarization and electronic
magnetization. It does not prove that the assumed nonunitary state is the
self-consistent thermodynamic ground state of a particular microscopic
interaction.
