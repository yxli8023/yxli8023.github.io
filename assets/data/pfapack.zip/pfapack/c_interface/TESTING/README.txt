Overview
--------

This directory contains an extensive test suite for the C interface to
the PFAPACK library.  Modify the makefile to choose your favorite
compilers and LAPACK library, and compile and run the test with
'make'. The test programs indicate whether they are successful or not.
