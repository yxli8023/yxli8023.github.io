# 计算mirror不变点上Wannier 能带对应的镜面本征值
@everywhere using SharedArrays, LinearAlgebra,Distributed,DelimitedFiles,Printf,Arpack
#-------------------------------------------------------------------------------
@everywhere function pauli()
    # 构建Pauli矩阵
    hn::Int64 = 2
    g0 = zeros(ComplexF64,hn,hn)
    gx = zeros(ComplexF64,hn,hn)
    gy = zeros(ComplexF64,hn,hn)
    gz = zeros(ComplexF64,hn,hn)
    #---------------
    g0[1,1] = 1
    g0[2,2] = 1

    gx[1,2] = 1
    gx[2,1] = 1

    gy[1,2] = -im
    gy[2,1] = im

    gz[1,1] = 1
    gz[2,2] = -1
    return g0,gx,gy,gz
end
#---------------------------------------------------------------
@everywhere function hamset(kx::Float64,ky::Float64,d0::Float64)::Matrix{ComplexF64}
    # m0::Float64 = 1.
    hn::Int64 = 8
    m0::Float64 = 1.5
    tx::Float64 = 1.0
    
    ty::Float64 = 1.0
    ax::Float64 = 1.0
    ay::Float64 = 1.0
    # d0::Float64 = 0.
    dx::Float64 = 0.2
    dy::Float64 = -dx
    mu::Float64 = 0.0
    ham = zeros(ComplexF64,hn,hn)
    s0,sx,sy,sz = pauli()
    g1 = kron(s0,sz,sz)
    g2 = kron(sz,sx,s0)
    g3 = kron(s0,sy,sz)
    g4 = kron(sy,s0,sy) # pairing
    g5 = kron(s0,s0,sz) # chemical potential
    ham = (m0 - tx*cos(kx) - ty*cos(ky))*g1 + ax*sin(kx)*g2 + ay*sin(ky)*g3 + (d0 + dx*cos(kx) + dy*cos(ky))*g4 - mu*g5
    return ham
end
#----------------------------------------------------------------------------------
@everywhere function mirror()
    # 构造镜面操作算符
    s0,sx,sy,sz = pauli()
    # mx = kron(sx,sx,sx) # x方向镜面操作
    # my = kron(sx,sy,sx) # y方向镜面操作

    mx = im*kron(sy,sx,sy) # x方向镜面操作
    my = im*kron(sx,sy,sx) # y方向镜面操作
    return  mx,my
end
#--------------------------------------------------------------------------------------
@everywhere function Wilsonkx(ky::Float64,m0::Float64)
    nk::Int64 = 100
    hn::Int64 = size(hamset(0.0,0.0,m0))[1]
    Nocc::Int64 = Int(hn/2)
    wave = zeros(ComplexF64,hn,hn,nk)
    wan = zeros(ComplexF64,Nocc,Nocc)
    F0 = zeros(ComplexF64,Nocc,Nocc)
    vec2 = zeros(ComplexF64,Nocc,Nocc)  # 重新排列顺序后Wannier Hamiltonian的本征矢量
    klist = range(0, 2*pi, length = nk)
    for ix in 1:nk 
        kx = klist[ix]
        val,vec = eigen(hamset(ky,kx,m0))
        wave[:,:,ix] = vec[:,:]
    end
    wave[:,:,nk] = wave[:,:,1] # 波函数首尾相接
    for i1 in 1:Nocc
        F0[i1,i1] = 1
    end
    for i1 in 1:nk - 1
        for i2 in 1:Nocc
            for i3 in 1:Nocc
                wan[i2,i3] = wave[:,i2,i1 + 1]' * wave[:,i3,i1]   # 计算Berry联络
            end
        end
        sv1 = svd(wan)
        wan = sv1.U * sv1.Vt
        F0 = wan * F0 # 构造Wannier 哈密顿量
    end
    val,vec = eigen(F0) 
    for i0 in 1:Nocc
        vec2[:,i0] = vec[:,sortperm(map(angle,val))[i0]] # 对求解得到的本征矢量按照本征值大小排列
    end
    return vec2  # 给出所有Wannier 本征值对应的本征态
end
#-------------------------------------------------------------------------------------
@everywhere function Wilsonky(ky::Float64,m0::Float64)
    nk::Int64 = 100
    hn::Int64 = size(hamset(0.0,0.0,m0))[1]
    Nocc::Int64 = Int(hn/2)
    wave = zeros(ComplexF64,hn,hn,nk)
    wan = zeros(ComplexF64,Nocc,Nocc)
    F0 = zeros(ComplexF64,Nocc,Nocc)
    vec2 = zeros(ComplexF64,Nocc,Nocc)  # 重新排列顺序后Wannier Hamiltonian的本征矢量
    klist = range(0, 2*pi, length = nk)
    for ix in 1:nk # 固定ky，沿着kx方向计算Wilson loop
        kx = klist[ix]
        val,vec = eigen(hamset(kx,ky,m0))
        wave[:,:,ix] = vec[:,:]
    end
    wave[:,:,nk] = wave[:,:,1] # 波函数首尾相接
    for i1 in 1:Nocc
        F0[i1,i1] = 1
    end
    for i1 in 1:nk - 1
        for i2 in 1:Nocc
            for i3 in 1:Nocc
                wan[i2,i3] = wave[:,i2,i1 + 1]' * wave[:,i3,i1]   # 计算Berry联络
            end
        end
        sv1 = svd(wan)
        wan = sv1.U * sv1.Vt
        F0 = wan * F0 # 构造Wannier 哈密顿量
    end
    val,vec = eigen(F0) # 对求解得到的本征矢量按照本征值大小排列
    for i0 in 1:Nocc
        vec2[:,i0] = vec[:,sortperm(map(angle,val))[i0]] # 按照顺序对本征态进行排列
    end
    return vec2  # 给出所有Wannier 本征值对应的本征态
end
#------------------------------------------------------------------------------------
@everywhere function Nestedkx(m0::Float64,kx::Float64,ky::Float64)
    # 对应的是y方向上的Nested Wilson loop
    hn::Int64 = size(hamset(0.0,0.0,m0))[1] # 直接通过哈密顿量来获取其维度，程序具有通用性
    Nocc::Int64 = Int(hn/2) # 获取占据态的数量
    wann_vec = Wilsonkx(kx,m0) # ky 方向已经被积掉
    val,vec = eigen(hamset(kx,ky,m0)) 
    wmu = zeros(ComplexF64,Nocc,hn)  
    for i3 in 1:Nocc # 遍历Wannier sector中的每一个Wannier 能带
        for i4 in 1:Nocc # 遍历Wannier 本征态中的每个分量
            wmu[i3,:] += vec[:,i4] * wann_vec[i4,i3]
        end
    end
    return wmu # 得到每个Wannier能带对应的新的Wannier basis
end
#-----------------------------------------------------------------------
@everywhere function Nestedky(m0::Float64,kx::Float64,ky::Float64)
    # 对应的是x方向上的Nested Wilson loop
    hn::Int64 = size(hamset(0.0,0.0,m0))[1] # 直接通过哈密顿量来获取其维度，程序具有通用性
    Nocc::Int64 = Int(hn/2) # 获取占据态的数量
    wann_vec = Wilsonky(ky,m0) # Wilson loop的本征态
    val,vec = eigen(hamset(kx,ky,m0)) # 哈密顿量本征态
    wmu = zeros(ComplexF64,Nocc,hn)  # 用来构建新的Wannier basis
    for i3 in 1:Nocc # 遍历Wannier sector中的每一个Wannier 能带
        for i4 in 1:Nocc # 遍历Wannier 本征态中的每个分量
            wmu[i3,:] += vec[:,i4] * wann_vec[i4,i3]
        end
    end
    return wmu # 得到每个Wannier能带对应的新的Wannier basis
end
#------------------------------------------------
@everywhere function mirroreigval(m0::Float64,kx::Float64,ky::Float64)
    # m0::Float64 = 1.5
    hn::Int64 = size(hamset(0.0,0.0,m0))[1] # 直接通过哈密顿量来获取其维度，程序具有通用性
    Nocc::Int64 = Int(hn/2) # 获取占据态的数量
    # kx::Float64 = 0
    # ky::Float64 = pi
    re1 = zeros(Float64,Nocc)
    re2 = zeros(Float64,Nocc)
    mux = Nestedkx(m0,kx,ky)
    muy = Nestedky(m0,kx,ky)
    mx,my = mirror()
    for i0 in 1:Nocc
        re1[i0] = imag(mux[i0,:]' * mx * mux[i0,:])  # Mirror-Y 操作本征值

        re2[i0] = imag(muy[i0,:]' * my * muy[i0,:])  # Mirror-X 操作本征值
    end
    return re1,re2
end
#--------------------------------------------------
@everywhere function m0chnage(m0list,kx,ky)
    hn::Int64 = size(hamset(0.0,0.0,1.0))[1] # 直接通过哈密顿量来获取其维度，程序具有通用性
    Nocc::Int64 = Int(hn/2) # 获取占据态的数量
    r1list = zeros(length(m0list),Nocc)
    r2list = zeros(length(m0list),Nocc)
    i0 = 1
    for m0 in m0list
        r1list[i0,:] = mirroreigval(m0,kx,ky)[1]
        r2list[i0,:] = mirroreigval(m0,kx,ky)[2]
        i0 += 1
    end
    re1 = (r1list[:,1] + r1list[:,2])/2
    re2 = (r2list[:,1] + r2list[:,2])/2
    return re1,re2
end
#-------------------------------------------------
@everywhere function phasex(m0list)
    kx = 0.0
    ky = 0.
    re1,re2 = m0chnage(m0list,kx,ky)
    kx = pi*1.0
    ky = 0.
    re3,re4 = m0chnage(m0list,kx,ky)

    mxlist = zeros(Float64,length(m0list))

    for i0 in 1:length(m0list)
        mxlist[i0] = sign(re1[i0] * re3[i0])
    end

    fn1 = "mx-dw.dat"
    f1 = open(fn1,"w")
    x0 = (a->(@sprintf "%3.2f" a)).(m0list)
    y0 = (a->(@sprintf "%7.5f" a)).(mxlist)
    writedlm(f1,[x0 y0],'\t')
    close(f1)
end
#-------------------------------------------------
@everywhere function phasey(m0list)
    kx = 0.0
    ky = 0.
    re1,re2 = m0chnage(m0list,kx,ky)
    kx = 0.0
    ky = 1.0*pi
    re3,re4 = m0chnage(m0list,kx,ky)

    mylist = zeros(Float64,length(m0list))

    for i0 in 1:length(m0list)
        mylist[i0] = sign(re2[i0] * re4[i0])
    end

    fn1 = "my-dw.dat"
    f1 = open(fn1,"w")
    x0 = (a->(@sprintf "%3.2f" a)).(m0list)
    y0 = (a->(@sprintf "%7.5f" a)).(mylist)
    writedlm(f1,[x0 y0],'\t')
    close(f1)
end
#-----------------------------------------------
@everywhere function main()
    m0list = 0:0.01:1
    phasex(m0list)
    phasey(m0list)
end
#--------------------------------------------------
@time main()

