from telnetlib import X3PAD
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
import os
config = {
"font.size": 30,
"mathtext.fontset":'stix',
"font.serif": ['SimSun'],
}
rcParams.update(config) # Latex 字体设置
#---------------------------------------------------------
def mirrorval(cont):
    # 单独画出每个以文件中的数据
    #da1 = "m" + str(cont) + "-pro-ox"  + ".dat"
    #da2 = "m" + str(cont) + "-pro-oy"  + ".dat"
    da1 = "mx-dw.dat"
    da2 = "my-dw.dat"
    picname = "mirrorval-" + str(cont) + ".png"
    os.chdir(os.getcwd())# 确定用户执行路径
    x0 = []
    y0 = []
    with open(da1) as file:
        da = file.readlines()
        for f1 in da:
            if len(f1) > 3:
                ldos = [float(x) for x in f1.strip().split()]
                x0.append(ldos[0])
                y0.append(ldos[1])
    y0 = np.array(y0)
    plt.figure(figsize=(10,8))
    #-------------------------
    # 颜色填充
    x1 = np.linspace(-4,0,50)
    x2 = np.linspace(0,8,50)
    x3 = np.linspace(8,10,50)
    y1 = 1.5 + np.sqrt(x1**2*0)
    y2 = -1.5 + np.sqrt(x1**2*0)
    # plt.fill_between(x1,y2,y1,color = "lightblue", alpha = 0.3)
    # plt.fill_between(x2,y2,y1,color = "pink",alpha = 0.3)
    # plt.fill_between(x3,y2,y1,color = "lightblue", alpha = 0.3)
    #----------------------------------------------------------------
    plt.scatter(x0, y0, s = 30, color = 'lightskyblue', label = "$a_{M_x}(0)a^*_{M_x}(\pi)$", marker = "^")
    x1 = []
    y1 = []
    with open(da2) as file:
        da = file.readlines()
        for f1 in da:
            if len(f1) > 3:
                ldos = [float(x) for x in f1.strip().split()]
                x1.append(ldos[0])
                y1.append(ldos[1])
    y1 = np.array(y1)
    # print(y0)
    # sc = plt.scatter(x0, y0, c = z1, s = 2,vmin = 0, vmax = 1, cmap="magma")
    plt.scatter(x1, y1, s = 30, color = 'deeppink', label = "$a_{M_y}(0)a^*_{M_y}(\pi)$", marker = "D" )
    font2 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 40,
             }
    font3 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 20,
             }
    plt.xlim(np.min(x1),np.max(x1))
    plt.ylim(-1.5,1.5)
    plt.xlabel("$m_0$",font2)
    plt.yticks([-1,0.,1],fontproperties='Times New Roman', size = 40)
    x0min = np.min(x1)
    x0max = np.max(x1)
    plt.xticks([x0min,x0min/2,0,x0max/2,x0max],fontproperties='Times New Roman', size = 40)
    plt.legend(loc = 'upper left', bbox_to_anchor=(0.0,0.8), shadow = True, prop = font3, markerscale = 1, borderpad  = 0.1)
    #plt.text(x = 0.6,y = 0.7,s = 'MCM', fontdict=dict(fontsize=20, color='black',family='Times New Roman'))
    #plt.text(x = 0.1,y = 0.7,s = 'NSC', fontdict=dict(fontsize=20, color='black',family='Times New Roman'))
    # plt.vlines(x = 0, ymin = -1.5, ymax = 1.5,lw = 3.0, colors = 'black', linestyles = '--')
    # plt.vlines(x = 2, ymin = -1.5, ymax = 1.5,lw = 3.0, colors = 'black', linestyles = '--')
    # plt.vlines(x = -2, ymin = -1.5, ymax = 1.5,lw = 3.0, colors = 'black', linestyles = '--')
    plt.savefig(picname, dpi = 100, bbox_inches = 'tight')
    plt.close()
#------------------------------------------------------------
def qxy(cont):
    # 通过Mx和Mx共同来决定电四极矩，这才是正确的结果
    da1 = "mx-dw.dat"
    da2 = "my-dw.dat"
    picname = "Qxy-" + str(cont) + ".png"
    os.chdir(os.getcwd())# 确定用户执行路径
    x0 = []
    y0 = []
    with open(da1) as file:
        da = file.readlines()
        for f1 in da:
            if len(f1) > 3:
                ldos = [float(x) for x in f1.strip().split()]
                x0.append(ldos[0])
                y0.append(ldos[1])
    plt.figure(figsize=(8,8))
    #-------------------------
    # 颜色填充
    x1 = np.linspace(-4,0,50)
    x2 = np.linspace(0,8,50)
    x3 = np.linspace(8,10,50)
    y1 = 1 + np.sqrt(x1**2*0)
    y2 = -1 + np.sqrt(x1**2*0)
    # plt.fill_between(x1,y2,y1,color = "lightblue", alpha = 0.3)
    # plt.fill_between(x2,y2,y1,color = "pink",alpha = 0.3)
    # plt.fill_between(x3,y2,y1,color = "lightblue",alpha = 0.3)
    #----------------------------------------------------------------
    y0 = np.array(y0)
    # plt.scatter(x0, y0, s = 30, color = 'lightskyblue', label = "$a_{M_x}(0)a_{M_x}(\pi)$", marker = "x")
    x1 = []
    y1 = []
    with open(da2) as file:
        da = file.readlines()
        for f1 in da:
            if len(f1) > 3:
                ldos = [float(x) for x in f1.strip().split()]
                x1.append(ldos[0])
                y1.append(ldos[1])
    y1 = np.array(y1)
    # print(y0)
    # sc = plt.scatter(x0, y0, c = z1, s = 2,vmin = 0, vmax = 1, cmap="magma")
    # plt.scatter(x1, y1, s = 30, color = 'deeppink', label = "$a_{M_y}(0)a_{M_y}(\pi)$", marker = "+" )
    re1 = []
    for i0 in range(len(y1)):
        if y0[i0]==-1 and y1[i0]==-1:
            re1.append(1/2.0)
        else:
            re1.append(0)
    re1 = np.array(re1)
    # print(len(x1))
    # print(len(re1))
    plt.scatter(x1, re1, s = 30, color = 'orange', label = "$q_{xy}$", marker = "o" )
    font2 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 40,
             }
    font3 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 20,
             }
    plt.xlim(np.min(x1),np.max(x1))
    plt.ylim(-1,1)
    plt.xlabel("$m_0$",font2)
    plt.ylabel("$q_{xy}$",font2)
    plt.yticks([-1,-0.5,0.,0.5,1],fontproperties='Times New Roman', size = 40)
    x0min = np.min(x1)
    x0max = np.max(x1)
    plt.xticks([x0min,x0min/2,0,x0max/2,x0max],fontproperties='Times New Roman', size = 40)
    plt.legend(loc = 'upper left', bbox_to_anchor=(0.7,0.8), shadow = True, prop = font3, markerscale = 1, borderpad  = 0.1)
    #plt.text(x = 0.6,y = 0.7,s = 'MCM', fontdict=dict(fontsize=20, color='black',family='Times New Roman'))
    #plt.text(x = 0.1,y = 0.7,s = 'NSC', fontdict=dict(fontsize=20, color='black',family='Times New Roman'))
    # plt.vlines(x = -0.5, ymin = -1.5, ymax = 1.5,lw = 3.0, colors = 'blue', linestyles = '--')
    # plt.vlines(x = 1.0, ymin = -1.5, ymax = 1.5,lw = 3.0, colors = 'blue', linestyles = '--')
    # plt.vlines(x = 2, ymin = -1.5, ymax = 1.5,lw = 3.0, colors = 'blue', linestyles = '--')
    # plt.vlines(x = -2, ymin = -1.5, ymax = 1.5,lw = 3.0, colors = 'blue', linestyles = '--')
    # plt.text(x = 1.5,y = -0.7,s = '$m_0$=1.0', fontdict=dict(fontsize=20, color='blue',family='Times New Roman'))
    # plt.text(x = -3,y = -0.7,s = '$m_0$=-0.5', fontdict=dict(fontsize=20, color='blue',family='Times New Roman'))
    # plt.text(x = 7,y = -0.7,s = '$m_0$=8.0', fontdict=dict(fontsize=20, color='black',family='Times New Roman'))
    # plt.text(x = -2,y = -0.7,s = '$m_0$=0.0', fontdict=dict(fontsize=20, color='black',family='Times New Roman'))
    plt.savefig(picname, dpi = 100, bbox_inches = 'tight')
    plt.close()
#---------------------------------------------------------
def main():
    for i0 in range(1,2):
        mirrorval(i0)
        qxy(i0) 
#---------------------------------------------------------
if __name__=="__main__":
    main()



