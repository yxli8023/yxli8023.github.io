import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib.cm as cm
import os
import re
plt.rc('font', family='Times New Roman')
config = {
"font.size": 30,
"mathtext.fontset":'stix',
"font.serif": ['SimSun'],
}
rcParams.update(config) # Latex 字体设置
#----------------------------------------------------------------------------
def WannierDETband():
    path = os.path.abspath('.')
    band_file = os.path.join(path,'BAND.dat')
    knode_file = os.path.join(path,'KLABELS')
    fermi_file = os.path.join(path,'FERMI_ENERGY')
    plt.figure(figsize = (10,8))

    #********************      DFT band ************************************************************   
    band_data = np.loadtxt(band_file)
    plt.plot(band_data[:,0],band_data[:,1:],color = 'b',linewidth = 2.0,label = "DFT")
    xmin = np.min(band_data[:,0])
    xmax = np.max(band_data[:,0])
    ymin = np.min(band_data[:,1:])
    ymax = np.max(band_data[:,1:])
    plt.xlim(xmin,xmax)
    # plt.ylim(ymin,ymax)
    plt.ylim(-6,6)

    with open(knode_file,"r",encoding = "utf-8") as f:
        lines = f.readlines()
    lines = lines[1:-3]
    knodes = []
    for i in range(len(lines)):
        knodes.append(str.split(lines[i]))
        knodes[i][1] = float(knodes[i][1])
        plt.axvline(x = knodes[i][1],linewidth = 1.5,color = 'silver')
    plt.axhline(y = 0,linewidth = 2.0,color = 'b',ls = "-.")
    knodes = list(map(list, zip(*knodes)))
    plt.xticks(knodes[1],list(knodes[0]),fontproperties='Times New Roman')


    #********************      Wannier band  ******************** 
    wannier_bandfile = os.path.join(path,'wannier90_band.dat')
    wannier_kptfile = os.path.join(path,'wannier90_band.kpt')
    wannier_labkptfile = os.path.join(path,'wannier90_band.labelinfo.dat')
    fermi_file = os.path.join(path,'FERMI_ENERGY')
    wannier_print = True
    if os.path.exists(wannier_bandfile) is True and wannier_print is True:
        wann_k = open(wannier_kptfile,"r",encoding = "utf-8")
        wann_l = open(wannier_labkptfile,"r",encoding = "utf-8")
        n_k = np.array(int(wann_k.readlines()[0]))
        lab = np.array(re.findall('[A-Z]*[A-Z]',wann_l.read()))
        fermi_energy = np.loadtxt(fermi_file)
        wann_k.close()
        wann_l.close()
        wb = np.loadtxt(wannier_bandfile)
        wj = int(len(wb)/n_k)
        for j in range(wj):
            if j == wj - 2:
                plt.plot(wb[:,0][j*n_k:j*n_k+n_k],wb[:,1][j*n_k:j*n_k+n_k] - fermi_energy,color = 'r',ls = '--',linewidth = 2.0,label = "Wannier")
            else:
                plt.plot(wb[:,0][j*n_k:j*n_k+n_k],wb[:,1][j*n_k:j*n_k+n_k] - fermi_energy,color = 'r',ls = '--',linewidth = 2.0)
    plt.legend(loc='upper right', shadow = True, fancybox = True)
    #********************************************************************************       
    plt.tick_params(axis='x',width = 0,length = 10)
    plt.tick_params(axis='y',width = 0,length = 10)
    ax = plt.gca()
    ax.spines["bottom"].set_linewidth(1.5)
    ax.spines["left"].set_linewidth(1.5) 
    ax.spines["right"].set_linewidth(1.5)
    ax.spines["top"].set_linewidth(1.5)
    # plt.show()
    plt.savefig("bandstructure.png",dpi = 300,bbox_inches = 'tight',transparent=True)
#-----------------------------------------------------------------------------------------------------
def plotfs(mu,numk):
    # 费米面以及极化率绘制
    dataname = "fermi-mu-" + str(mu) + "-numk-" + str(numk) + ".dat"
    dataname = "FS.dat"
    # dataname = "Honeycomb-fermi-mu-" + str(mu) + ".dat"
    # dataname = "Square-fermi-mu-" + str(mu) + ".dat"
    # dataname = "fermi-mu-" + str(mu) + ".dat"
    # dataname = "Honeycomb-fermivs-" + str(mu) + ".dat"
    # dataname = "maxvals-chi0-" + str(numk) + ".dat"
    # picname = os.path.splitext(dataname)[0] + "-" + str(num) + ".png"
    picname = os.path.splitext(dataname)[0] + ".png"
    da = np.loadtxt(dataname) 
    plt.figure(figsize = (10,8))
    sc = plt.scatter(da[:,0],da[:,1], s = 1, c = da[:,2],cmap = "jet")
    #-------------------------------------------------
    r0 = 5 
    hex = [np.sqrt(3)/2 * r0,np.sqrt(3)/4 * r0,-np.sqrt(3)/4 * r0,-np.sqrt(3)/2 * r0,-np.sqrt(3)/4 * r0,np.sqrt(3)/4 * r0,np.sqrt(3)/2 * r0]
    hey = [0 * r0 ,3/4 * r0 ,3/4 * r0 ,0 * r0 ,-3/4 * r0 ,-3/4 * r0 ,0 * r0]
    plt.plot(hex,hey,c = "black",lw = 2,ls = "--")
    #-------------------------------------------------
    cb = plt.colorbar(sc,fraction = 0.1,ticks = [np.min(da[:,2]),np.max(da[:,2])])  # 调整colorbar的大小和图之间的间距
    # cb.ax.set_yticklabels([r'$d_{3z^2-r^2}$', r'$d_{x^2-y^2}$']) 
    xtic = [-2 * np.pi,0,2 * np.pi]
    xticlab = ["$-2\pi$","$0$","$2\pi$"]
    plt.xticks(xtic,list(xticlab),fontproperties='Times New Roman', size = 40)
    plt.yticks(xtic,list(xticlab),fontproperties='Times New Roman', size = 40)
    xmin = np.min(da[:,0])
    xmax = np.max(da[:,0])
    ymin = np.min(da[:,1])
    ymax = np.max(da[:,1])
    # plt.xlim(xmin,xmax)
    # plt.ylim(ymin,ymax)
    plt.xlim(-2 * np.pi,2 * np.pi)
    plt.ylim(-2 * np.pi,2 * np.pi)
    plt.tick_params(axis='x',width = 0,length = 10)
    plt.tick_params(axis='y',width = 0,length = 10)
    ax = plt.gca()
    ax.spines["bottom"].set_linewidth(1.5)
    ax.spines["left"].set_linewidth(1.5) 
    ax.spines["right"].set_linewidth(1.5)
    ax.spines["top"].set_linewidth(1.5)
    # plt.show()
    plt.savefig(picname, dpi = 300,bbox_inches = 'tight',transparent=True)
    plt.close()

#-----------------------------------------------------------------------------------------------------
# WannierDETband()
numk = 100
mu = -2.15
plotfs(format(mu,".2f"),format(numk,".2f"))

