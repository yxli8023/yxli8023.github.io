#  自洽计算配对序参量
#  H(k) = t(cos kx + cos ky)  正方晶格最近邻
#-------------------------------------------------------------------------------
@everywhere using SharedArrays,LinearAlgebra,Distributed,DelimitedFiles,Printf,BenchmarkTools,Arpack,Dates
#  利用Arpack进行稀疏矩阵对角化,因为只在RPA框架中一般只需要矩阵最大或者最小本征值
#-------------------------------------------------------------------------------
@everywhere function matset_SC(kx::Float64,ky::Float64,delta::ComplexF64)
    t1::Float64 = 1.0
    mu::Float64 = 1.0
    Ham = zeros(ComplexF64,2,2)
    Ham[1,1] = t1 * (cos(kx) + cos(ky)) - mu
    Ham[2,2] = -t1 * (cos(kx) + cos(ky)) + mu
    Ham[1,2] = delta
    Ham[2,1] = conj(delta)
    return Ham
end 
#-------------------------------------------------------------------------------
@everywhere function BZpoints(kn::Int64)
    knn::Int64 = 2 * kn + 1
    klist = zeros(Float64,2,knn^2)
    ik0 = 0
    for ikx in -kn:kn
    for iky in -kn:kn
        ik0 += 1
        klist[1,ik0] = ikx * pi/kn
        klist[2,ik0] = iky * pi/kn
    end 
    end
    return  klist
end
#-------------------------------------------------------------------------------
# @everywhere function fermi(ek::Float64)
#     kbt::Float64 = 1E-10
#     return 1.0/(exp(ek/kbt) + 1.0)
# end
@everywhere function fermi(ek::Float64)
    if (ek<0)
        return 1.0
    else
        return 0.0
    end
end
#-------------------------------------------------------------------------------
@everywhere function self_delta(U0::Float64)
    # 自洽计算配对序参量
    delta::ComplexF64 = 0.1
    delta_new::ComplexF64 = 0.1
    diff_delta::Float64 = 0.1
    diff_eps::Float64 = 1E-6
    hn::Int64 = 2   # 哈密顿量维度
    re1 = zeros(Float64,hn,hn)
    kn::Int64 = 2E2
    dk::Float64 = 1.0/kn
    klist = BZpoints(kn)  # 布里渊区撒点

    while diff_delta > diff_eps 
        delta_new = 0.0
        ik0 = 0
        for ikx in -kn:kn
        for iky in -kn:kn
            ik0 += 1
            kx = klist[1,ik0]
            ky = klist[2,ik0]
            Ham = matset_SC(kx,ky,delta)
            val,vec = eigen(Ham)
            for ie0 in 1:hn
                re1[ie0,ie0] = fermi(real(val[ie0]))
            end
            temp = vec * re1 * vec'
            delta_new += temp[1,2]
        end 
        end
        delta_new = -U0 * delta_new * dk^2
        diff_delta = abs(delta_new - delta)
        delta = delta_new
    end 
    return delta
end
#-------------------------------------------------------------------------------
@everywhere function main()
    Un::Int64 = 100
    U0list = range(0,1,length = Un + 1)
    order = SharedArray(zeros(ComplexF64,Un + 1))
    @sync @distributed for iu in 1:Un + 1  # 并行计算
        order[iu] = self_delta(U0list[iu])
    end
    fx1 ="julia-order.dat"
    f1 = open(fx1,"w")
    x0 = (a->(@sprintf "%15.8f" a)).(U0list)
    y0 = (a->(@sprintf "%15.8f" a)).(real(order))
    z0 = (a->(@sprintf "%15.8f" a)).(imag(order))
    writedlm(f1,[x0 y0 z0],"\t")
    close(f1)

end
#-------------------------------------------------------------------------------
@time main()
